#Usage of db-migrate

##Install db-migration globally

 npm install -g db-migrate
 npm install -g db-migrate-pg

##Create a new migration script

 db-migrate create <<migration-name> --config ./migrations/database.json --env "local"

##Run the script to update local database
 
 db-migrate up --config ./migrations/database.json --env "local"

For further reference - https://db-migrate.readthedocs.io/en/latest/search/

PS: NEVER CHANGE the exisitng migration 

For reference:
Productioin DB : "postgresql://root:sa3iuF8KsbafS87w3IPJ@kantaldev.cdz5jsfooxxm.us-west-1.rds.amazonaws.com:5432/kantal"
Local DB : "postgresql://leaderportal:leaderportal@localhost:5432/leaderportal"