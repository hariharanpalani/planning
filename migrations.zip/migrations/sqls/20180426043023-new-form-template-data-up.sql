
UPDATE public.form_template SET is_default = false WHERE id = 1;

INSERT INTO public.form_template (form_id, version_id, is_default, created_datetime, created_user_id, summary_fields, data, sort_order_id ) VALUES (1, 2, true, '2018-04-24 10:32:52.952296', 1, NULL, 
'[{
    settings: {
        hideActionButtons: [
            ''print'', ''mail''
        ]
    },
    fields: [
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''name'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Your Name'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''department'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Your Department'',
                        required: true
                    }
                },
                {
                    key: ''positiontitle'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Position title (of the role you are hiring)'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''purposeofposition'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Purpose of the position (Summary/headline of objectives of the position)'',
                        required: true,
                        rows: 5
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''location'',
                    type: ''select'',
                    className: ''col-lg-4'',
                    templateOptions: {
                        label: ''Location'',
                        required: true,
                        placeholder: ''Choose'',
                        options: [
                            { label: ''NYC'', value: 0 },
                            { label: ''Lund'', value: 1 },
                            { label: ''Others (Please fill 5A)'', value: 2 }]
                    },
                    defaultValue: '''',
                },
                {
                    key: ''otherlocation'',
                    type: ''input'',
                    className: ''col-lg-4'',
                    templateOptions: {
                        label: ''Other Location'',
                        required: true,
                    },
                    hideExpression: ''model.location !== "2"'',
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''typeofcontract'',
                    type: ''select'',
                    className: ''col-lg-4'',
                    templateOptions: {
                        label: ''Type of Contract'',
                        placeholder: ''Choose'',
                        required: true,
                        options: [
                            { label: ''Permanent Employment'', value: 0 },
                            { label: ''Contract'', value: 1 },
                            { label: ''Internship'', value: 2 }],
                    },
                    defaultValue: '''',
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''keyduties'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Key Duties & Responsibilities : (Please be specific; atleast 6-7 bullets)'',
                        required: true,
                        rows: 5
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''keyresults'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Key Result Areas (what will be the performance expectations)'',
                        required: true,
                        rows: 5
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''positionreport'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Who will this position report to'',
                        required: true
                    }
                },
                {
                    key: ''directreportees'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Who will be the direct reportees''
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''qualifications'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Qualifications'',
                        required: true
                    }
                },
                {
                    key: ''experiencerange'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Experience range (in years)'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''desiredexperience'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Desired experiences or specific skill sets'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''competencies'',
                    type: ''multicheckbox'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Competencies (Choose 5 from the list)'',
                        required: true,
                        min: 5,
                        options: [
                            { ''key'': ''drivesvision'', ''value'': ''Drives Vision and Purpose'' },
                            { ''key'': ''communication'', ''value'': ''Communicates Effectively'' },
                            { ''key'': ''strategic'', ''value'': ''Strategic Mindset'' },
                            { ''key'': ''balanced'', ''value'': ''Balances Stakeholders'' },
                            { ''key'': ''business-insight'', ''value'': ''Business Insight'' },
                            { ''key'': ''plans'', ''value'': ''Plans and Aligns'' },
                            { ''key'': ''optimized'', ''value'': ''Optimizes Work Processes'' },
                            { ''key'': ''drives'', ''value'': ''Drives Engagement'' },
                            { ''key'': ''decision'', ''value'': ''Decision Quality'' },
                            { ''key'': ''tech-savy'', ''value'': ''Tech Savvy'' },
                            { ''key'': ''collab'', ''value'': ''Collaborates'' },
                            { ''key'': ''learning'', ''value'': ''Nimble Learning'' },
                            { ''key'': ''innovation'', ''value'': ''Cultivates Innovation'' },
                            { ''key'': ''adaptability'', ''value'': ''Situational Adaptability'' }
                        ]
                    },
                    validators: {
                        ip: {
                            expression: (c) => {
                                return Object.keys(c.value)
                                    .filter(key => !!c.value[key])
                                    .length > 4;
                            },
                            message: (error, field) => `Choose at least 5 competencies`,
                        },
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''additionalcomments'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Additional Comments'',
                        rows: 10
                    }
                }
            ]
        }
    ]
}]', 1);

UPDATE public.form_template SET is_default = false WHERE id = 2;

INSERT INTO public.form_template (form_id, version_id, is_default, created_datetime, created_user_id, summary_fields, data, sort_order_id) VALUES (2, 2, true, '2018-04-25 07:32:52.952296', 1, NULL, '[{
     settings: {
        hideActionButtons: [
            ''print'', ''mail''
        ]
    },fields: [{
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''name'',
                type: ''input'',
                className: ''col-lg-6'',
                templateOptions: {
                    label: ''Your Name'',
                    required: true
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''aboutprogenics'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''What do you know about Progenics'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''idealjob'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''Describe your ideal job'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''aboutthisposition'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''What interests you most about this position?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''motivatesyourbestwork'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''What motivates you to do your best work?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''mostfrustratingwork'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''What do you find most frustrating at work?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''projectyoureallyexcited'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''Tell me about a project that got you really excited?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''conditionyouworkbest'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''Under what condition do you work best?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''aboutyourlastposition'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''Tell me about your last position and what you did?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''yourmistakewayofcorrected'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''Tell me about the last time you made a mistake and how you corrected it?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''importantthingyoulearnedinjob'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''What is the most important thing you learned at previous or in your current job?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''previouspositionspreparedyou'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''How have your previous positions prepared you for this one?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''gradeyourabilitytocommunicate'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''How would you grade your ability to communicate with Upper level management, Customers, and/or peers?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    }]
}]', 2);

UPDATE public.form_template SET is_default = false WHERE id = 4;

INSERT INTO public.form_template (form_id, version_id, is_default, created_datetime, created_user_id, summary_fields, data, sort_order_id) VALUES (6, 2, true, '2018-04-25 07:32:52.952296', 1, NULL, '[{
     settings: {
        hideActionButtons: [
            ''print'', ''mail''
        ]
    },fields: [
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''name'',
                    type: ''input'',
                    className: ''col-lg-6 form-title-ui'',
                    templateOptions: {
                        label: ''Name'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [{
                key: ''thirtysixtyninty'',
                type: ''30-60-90'',
                defaultValue: [{}],
                fieldArray: {
                    fieldGroup: [
                        {
                            key: ''understandingcompany'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Understanding Company''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''understandsystemtools'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Understanding various systems & tools''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''meetingleaders'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Meetings with key leaders''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''meetingteam'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Meeting with team & other members''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''goalsetting'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Goal setting''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''goalsetting'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Goal setting''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''specialproject'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Special Project''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''improvement'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                // tslint:disable-next-line:max-line-length
                                label: ''Continuous improvement : 30 (identify 1-2 areas) 60 - propose improvements 90 - carry out improvements''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''colleguefeedback'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Colleague Feedback''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''managerfeedback'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Manager Feedback''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        }
                    ]
                }
            }]
        }
    ]
}]', 5);

UPDATE public.form_template SET is_default = false WHERE id = 3;

INSERT INTO public.form_template (form_id, version_id, is_default, created_datetime, created_user_id, summary_fields, data, sort_order_id) VALUES (3, 2, true, '2018-04-25 07:32:52.952296', 1, NULL, '[{
    settings: {
        hideActionButtons: [
            ''print'', ''mail''
        ]
    },
    fields: [
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''email'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Email address'',
                        type: ''email'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''name'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Your Name'',
                        required: true
                    }
                },
                {
                    key: ''position'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Position being hired for'',
                        required: true
                    }
                },
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''dateofinterview'',
                    type: ''input'',
                    className: ''col-lg-4'',
                    templateOptions: {
                        label: ''Date of interview'',
                        type: ''date'',
                        required: true
                    }
                },
                {
                    key: ''candidatename'',
                    type: ''input'',
                    className: ''col-lg-8'',
                    templateOptions: {
                        label: ''Name of the candidate'',
                        required: true
                    }
                },
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''location'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Candidate Location'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            key: ''inverviewassessmentheader'',
            type: ''section-header'',
            templateOptions: {
                label: ''Interview Assessment''
            }
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''summary'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Summary of the interview'',
                        description: ''How did the interview go? Level of interest/enthusiasm from the candidate. What did/did not go well?'',
                        rows: 5
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''technicalassessment'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Technical Assessment'',
                        description: ''How qualified and experienced is the candidate technically for this role? What areas would you like to highlight in terms of her/his technical skills? Where did you observe are the gaps?'',
                        rows: 5
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''competencyrating'',
                    type: ''rating'',
                    templateOptions: {
                        label: ''How would you assess the candidate on the following Competencies? '',
                        description: ''Based on your discussion how would you evaluate the candidate\''s competencies. You may want to use the Behavioural Event Interview (BEI) Guide having the list of questions.''
                    },
                    defaultValue: [{}],
                    fieldArray: {
                        fieldGroup: [
                            {
                                key: ''drivesvision'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Drives Vision and Purpose'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''comminucation'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Communicates Effectively'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''strategic'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Strategic Mindset'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''balancestakeholder'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Balances Stakeholders'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''businessinsight'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Business Insight'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''plansandaligns'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Plans and Aligns'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''optimizesworkprocess'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Optimizes Work Processes'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''drivesengagement'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Drives Engagement'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''decisionquality'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Decision Quality'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''techsavvy'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Tech Savvy'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''collaborates'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Collaborates'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''niblelearning'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Nimble Learning'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''cultivatesinnovation'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Cultivates Innovation'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''situationaladaptability'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Situational Adaptability'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            }
                        ]
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''highlight'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Based on the above Competencies, is there anything you would like to highlight ?'',
                        description: ''Aspects around what was his/her strengths and essential for the role. Anything that is critical for the role but the candidate did/did not possess ?'',
                        rows: 5
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            key: ''finalrecommendation'',
            type: ''section-header'',
            templateOptions: {
                label: ''Final Recommentation''
            }
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''decision'',
                    type: ''radio'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''What is your decision regarding the candidate?'',
                        options: [
                            { key: ''no'', value: ''Not to proceed'' },
                            { key: ''yes'', value: ''Proceed with next round'' }
                        ]
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''rationale'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Your rationale behind the decision'',
                        rows: 5
                    }
                }
            ]
        }
    ]
}]', 3);


UPDATE public.form_template SET is_default = false WHERE id = 5;

INSERT INTO public.form_template (form_id, version_id, is_default, created_datetime, created_user_id, summary_fields, data, sort_order_id) VALUES (5, 2, true, '2018-04-24 10:32:52.952296', 1, NULL, '[{
  settings: {
        hideActionButtons: [
            ''preview'', ''completed'', ''edit'', ''save''
        ],
        mode:''nonedit''
    },
    fields: [
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''0'',
                type: ''checklist'',
                templateOptions: {
                    label: ''Before Joining'',
                    options: [
                        ''Identify and Orient buddy'',
                        ''Announcement to department/team'',
                        ''Welcome Call'',
                        ''Create schedule for first week'',
                        ''Finalise roles & responsibilities'',
                        ''Discuss role, goals and projects with reporting manager''
                    ]
                }
            },
            {
                key: ''1'',
                type: ''checklist'',
                templateOptions: {
                    label: ''First Day'',
                    options: [
                        ''Welcome meeting'',
                        ''Introduction to buddy, department and team'',
                        ''Team Lunch'',
                        ''Orient to role, responsibilities, expectations & Organisation''
                    ]
                }
            },
            {
                key: ''2'',
                type: ''checklist'',
                templateOptions: {
                    label: ''First Day'',
                    options: [
                        ''Welcome meeting'',
                        ''Introduction to buddy, department and team'',
                        ''Team Lunch'',
                        ''Orient to role, responsibilities, expectations & Organisation''
                    ]
                }
            },
            {
                key: ''3'',
                type: ''checklist'',
                templateOptions: {
                    label: ''First Week'',
                    options: [
                        ''Identify learning needs'',
                        ''Department overview & touch points'',
                        ''Add to check in meetings & weekly catch up'',
                        ''Determine & complete 30-60-90 day plan''
                    ]
                }
            },
            {
                key: ''4'',
                type: ''checklist'',
                templateOptions: {
                    label: ''30 Days – Understand'',
                    options: [
                        ''Ensure new joiner is gets to know the Organisation’s culture'',
                        ''Capability to understand the Competencies and training requirements'',
                        ''Assign project and monitor'',
                        ''Build a career development plan with specific goals, metric and KPI’s''
                    ]
                }
            },
            {
                key: ''5'',
                type: ''checklist'',
                templateOptions: {
                    label: ''60 Days – Assess'',
                    options: [
                        ''Identify issues or pain points with the roles-develop plans to address and fix the issues'',
                        ''Get feedback from immediate reporting manager'',
                        ''Competency analysis and training requirement proposal'',
                        ''Extended team collaboration''
                    ]
                }
            },
            {
                key: ''6'',
                type: ''checklist'',
                templateOptions: {
                    label: ''90 Days – Optimise'',
                    options: [
                        ''Start to work on independent project'',
                        ''Ensure accountability'',
                        ''Consult with immediate manager for feedback about goals/metrics/KPIs going forward'',
                        ''Review development plan''
                    ]
                }
            }
        ]
    }
 ]
}]', 4);