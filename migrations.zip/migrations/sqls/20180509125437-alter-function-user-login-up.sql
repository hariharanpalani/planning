/* Replace with your SQL commands */

DROP FUNCTION public.validate_user_login(character varying, character varying, character varying);


CREATE FUNCTION validate_user_login(_email character varying, _password character varying, _login_ip character varying, _tenant_id uuid) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$

DECLARE success BOOLEAN;
DECLARE message CHARACTER VARYING(500);  
DECLARE password_hash CHARACTER VARYING(1000);
DECLARE is_user_exist BOOLEAN = false;
DECLARE password_hash_col CHARACTER VARYING(1000); 
DECLARE salt_col UUID;
DECLARE salt_col_var CHARACTER VARYING(100);
DECLARE is_disabled_col BOOLEAN = false;
DECLARE disabled_reason_col CHARACTER VARYING(1000);
DECLARE is_locked_col BOOLEAN;
DECLARE is_admin_col BOOLEAN;
DECLARE last_login_ip_col CHARACTER VARYING(50);
DECLARE last_login_datetime_col TIMESTAMP WITHOUT TIME ZONE;
DECLARE login_try_col INTEGER = 1;
DECLARE locked_datetime_col TIMESTAMP WITHOUT TIME ZONE;
DECLARE org_tenant_id_col UUID;
DECLARE org_full_name_col CHARACTER VARYING(250);
DECLARE org_logo_path_col CHARACTER VARYING(250);
DECLARE user_exist BOOLEAN;
DECLARE user_locked BOOLEAN;
DECLARE last_try BOOLEAN;
DECLARE is_locked_now BOOLEAN = false;
DECLARE return_data JSON;
DECLARE user_id_col INTEGER = 0;
BEGIN
success := false;
message := 'unable to validate user';

SELECT  u.password_hash, u.salt, u.disabled, u.disabled_reason, u.locked, 
		u.locked_datetime, u.tenant_id, u.is_admin, u.login_try, u.login_datetime, u.login_ip, u.User_Id INTO 
		password_hash_col, salt_col, is_disabled_col, message, is_locked_col, 
		locked_datetime_col,org_tenant_id_col, is_admin_col, login_try_col, last_login_datetime_col, last_login_ip_col, user_id_col
FROM "user" u WHERE u.email = _email AND u.tenant_id = _tenant_id;

IF (COALESCE(user_id_col,0) = 0) THEN
	message := 'User does not exist';
ELSEIF (COALESCE(is_disabled_col,false) = true) THEN
	message := 'User is disabled; Reason:' + message;
ELSEIF (is_locked_col = true AND locked_datetime_col > now()::timestamp ) THEN
	message := 'User is locked;';
ELSE
	salt_col_var := salt_col::"varchar";
	password_hash := crypt(_password, salt_col_var);
	IF (password_hash = password_hash_col) THEN
	
		UPDATE "user" SET last_login_ip = last_login_ip_col, last_login_datetime = last_login_datetime_col,
			login_datetime = now()::timestamp, login_ip = _login_ip,
			login_try = 0, locked = false, locked_datetime = NULL
		WHERE 
			email = _email;
		
		INSERT INTO log_user_login (email, ip, login_datetime, login_success )
		VALUES (_email, _login_ip, now()::timestamp, true);
		
		success := true;
		message := '';
	ELSE
		login_try_col := COALESCE(login_try_col,0) + 1;
		message := 'Password is not valid';
		
		IF (login_try_col >= 4) THEN
			is_locked_col :=  true;
			is_locked_now := true;
			locked_datetime_col := now()::timestamp + interval '24h';
		END IF;
		
		UPDATE "user" SET 
			login_try = login_try_col, 
			"locked" = CASE WHEN login_try_col >= 4 THEN true ELSE "locked" END, 
			locked_datetime = CASE WHEN login_try_col >= 4 THEN locked_datetime_col ELSE locked_datetime END
		WHERE 
			email = _email;
		
		INSERT INTO log_user_login (email, ip, login_datetime, login_success )
		VALUES (_email, _login_ip, now()::timestamp, false);
		
	END IF;
END IF;

IF ( success = false) THEN
	last_login_ip_col := NULL;
	last_login_datetime_col := NULL;
	user_id_col := NULL;
END IF;
return_data := (select row_to_json(t)
from (
	select success as success,
			message as message,
			is_locked_col as "locked",
			is_locked_now as lockednow,
			login_try_col as logintry,
			user_id_col as userid,
			last_login_ip_col as lastloginip,
			last_login_datetime_col as lastlogindatetime
) t);

RETURN return_data;
END

$$;
