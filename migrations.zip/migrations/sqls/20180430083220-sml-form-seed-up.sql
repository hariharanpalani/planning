INSERT INTO form_template (form_id, version_id, is_default, created_datetime, created_user_id, summary_fields, data, sort_order_id) 
VALUES (7, 1, true, '2018-03-30 10:04:50.265662', 1, '[{"field" : "title", "title" : "Title" }]','
[{  settings: {
        hideActionButtons: [ ]
    },
    fields:
    [
        {
            fieldGroupClassName: "row",
            fieldGroup: [
                {
                    key: "title",
                    type: "input",
                    className: "col-lg-6 form-title-ui",
                    templateOptions: {
                        label: "Title",
                        required: true
                    }
                }
            ]
        },
        {
            key: "sml",
            fieldGroup: [
                {
                    type: "sml",
                    fieldGroup: [
                        {
                            key: "shorttarget",
                            type: "sml-target-header",
                            templateOptions: {
                                label: "Short",
                                placeholder: "(Your Target)",
                                className:"sml-ui-short",
                                required: true
                            }
                        },
                        {
                            key: "mediumtarget",
                            type: "sml-target-header",
                            templateOptions: {
                                label: "Medium",
                                placeholder: "(Your Target)",
                                className: "sml-ui-medium",
                                required: true
                            }
                        },
                        {
                            key: "longtarget",
                            type: "sml-target-header",
                            templateOptions: {
                                label: "Long",
                                placeholder: "(Your Target)",
                                required: true,
                                className: "sml-ui-long",
                                isOngoing: true
                            }
                        },
                        {
                            key: "tasks",
                            type: "sml-target-row",
                            templateOptions: {
                                placeholder: "Task Details...",
                                targetCellProperties: {
                                    short: {
                                        key: "shorttarget",
                                        label: "Short",
                                        highlightClassname: "sml-ui-td-active-short"
                                    },
                                    medium: {
                                        key: "mediumtarget",
                                        label: "Medium",
                                        highlightClassname: "sml-ui-td-active-medium"
                                    },
                                    longFixed: {
                                        key: "longtarget",
                                        label: "Long",
                                        highlightClassname: "sml-ui-td-active-long-1"
                                    },
                                    longOngoing: {
                                        key: "longongoing",
                                        label: "Ongoing",
                                        highlightClassname: "sml-ui-td-active-long-2"
                                    },
                                }
                            }
                        }
                    ]
                }
            ]
        }
    ]
}]', 6);