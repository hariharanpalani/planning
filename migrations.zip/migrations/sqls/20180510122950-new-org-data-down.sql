/* Replace with your SQL commands */
delete from section where id in (5,6,7,8,9,10,11,12);
delete from category where id in (12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33);
delete from form where id in (8,9,10,11,12,13,14,18,19,22,23,24,25,27,28);
delete from form_template where form_id in (27,13,14,28,9,8,10,12,22,23,2419);
delete from resource where id in (13,14,15,16,17,18,19,20,21,22);

SELECT setval('user_user_id_seq', coalesce((select max(user_id) from "user"), 1), true); 
SELECT setval('section_id_seq', coalesce((select max(id) from section), 1), true); 
SELECT setval('category_id_seq', coalesce((select max(id) from category), 1), true); 
SELECT setval('resource_id_seq', coalesce((select max(id) from resource), 1), true); 
SELECT setval('form_id_seq1', coalesce((select max(id) from form), 1), true); 
SELECT setval('form_template_id_seq', coalesce((select max(id) from form_template), 1), true); 