DROP TABLE public.log_user_login;

DROP TABLE public.user_form_relation;

DROP TABLE public.form_data;

DROP TABLE public.form_template;

DROP TABLE public.form;

DROP TABLE public.resource;

DROP TABLE public.category;

DROP TABLE public.section;

DROP TABLE public."user";

DROP TABLE public.organization;

DROP SEQUENCE user_user_id_seq;

DROP SEQUENCE section_id_seq;

DROP SEQUENCE category_id_seq;

DROP SEQUENCE resource_id_seq;

DROP SEQUENCE form_id_seq1;

DROP SEQUENCE form_template_id_seq;

DROP SEQUENCE form_data_id_form_seq;

DROP SEQUENCE user_form_relation_id_seq;

DROP SEQUENCE log_user_login_auto_id_seq;