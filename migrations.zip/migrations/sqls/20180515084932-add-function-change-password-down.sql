
DROP FUNCTION public.change_password(character varying, character varying , character varying, UUID);