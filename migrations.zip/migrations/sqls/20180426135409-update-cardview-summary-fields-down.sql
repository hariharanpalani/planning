update form_template set summary_fields = null where form_id = 1;
update form_template set summary_fields = null where form_id = 2;
update form_template set summary_fields = null where form_id = 3;
update form_template set summary_fields = null where form_id = 6;
