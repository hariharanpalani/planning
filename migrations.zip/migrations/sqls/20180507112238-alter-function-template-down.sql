DROP FUNCTION public.update_form_template(integer, text, integer);

DROP FUNCTION public.get_form_template(integer);

CREATE OR REPLACE FUNCTION public.get_form_template(
	_form_template_id integer)
    RETURNS TABLE(
				template_id integer,
				section_id integer,
				form_name character varying,
				tenant_id uuid,
				title character varying,
				description character varying,
				form_type character varying, 
				fields text
	) 
    LANGUAGE 'sql'

    COST 100
    VOLATILE 
    ROWS 1000
AS $BODY$


select FT.id, cat.section_id, F.name,cat.tenant_id, F.title,F.description, F.form_type, FT.data as fields 
from form F 
join form_template FT on (F.id = FT.form_id) 
join category cat on (cat.id = f.category_id)
where FT.id = _form_template_id and F.is_active = true


$BODY$;




CREATE OR REPLACE FUNCTION get_section_detail(_section_id integer) RETURNS TABLE(id integer, title character varying, tenant_id uuid, logo_path character varying, form_items json, res_items json)
    LANGUAGE plpgsql
    AS $$

DECLARE form_items json;
DECLARE res_items json;
DECLARE categories json;
BEGIN
	
	--form items
	select json_agg(fi.items) into form_items from 
	(select  json_build_object('name', cat.title, 'items', 
			json_agg(
			json_build_object(
								'id', tmpl.id, 
								'name', frm.name, 
								'title', frm.title,
								'description', frm.description, 
								'type', frm.form_type
			) order by tmpl.sort_order_id
			)
			) as items 
	from section s
	inner join category cat on cat.section_id = s.id and cat.is_active = true
	left outer join form frm on frm.category_id = cat.id and  frm.is_active = true
	left outer join form_template tmpl on tmpl.form_id = frm.id and tmpl.is_default = true
	where s.id = _section_id and s.is_active = true and cat.name = 'forms'
	group by cat.title) fi;

	select json_agg(r.items) into res_items from 
	(select json_build_object('name', cat.title, 'items', 
			json_agg(
			json_build_object(
								'id', res.id, 
								'name', res.name, 
								'title', res.title,
								'description', res.description,
								'type', res.resource_type,
								'property', res.property
			) order by res.sort_order_id
			)
			) as items
	from category cat
	left outer join resource res on  res.category_id = cat.id and res.is_active = true	
	inner join section s on s.id = cat.section_id and s.is_active = true
	where s.id = _section_id and cat.is_active = true and cat.name != 'forms'	
	group by cat.title, cat.sort_order_id Order by cat.sort_order_id) r;

		
	RETURN QUERY select s.id , s.title,s.tenant_id, s.logo_path, form_items , res_items from "section" s where s.id = _section_id;
END 

$$;


