/* Replace with your SQL commands */


CREATE TYPE public.pagination_criteria AS
(
	page_number integer,
	page_size integer
);