INSERT INTO organization (description, full_name, tenant_id, unique_name, logo_path, domain_name, settings) VALUES ('Progenics company','Progenics','12bd322d-0dfd-4c94-9319-dccd8133bd6f','progenics','assets/img/progenics.png','progenics',
'{
    "contact_email": "contact@progenics.com",
    "logo_path": "assets/img/progenics-logo.png",
    "copy_right": "Copyright © 2018 Progenics",
    "title": "Progenics",
	"new_user_msg":"Support your success. If you have any feedback, write to us contact@progenics.com. Enjoy this access (it is by invite only), and continue to be the awesome leader you are!",
	"existing_user_msg":"Glad to have you back! What would you like to do today?"
}');
INSERT INTO organization (description, full_name, tenant_id, unique_name, logo_path, domain_name, settings) VALUES ('Kan Associates','Kan associates','f039d492-a55e-4fad-8a03-d77311ee8891','Kanassociates','assets/img/kanvas_logo.png','kanvas',
'{
    "contact_email": "contact@kanassociates.com",
    "logo_path": "assets/img/kanvas_logo.png",
    "copy_right": "Copyright © 2018 Kanassociates",
    "title": "Kanvas Talent",
	"new_user_msg":"Support your success. If you have any feedback, write to us contact@kanassociates.com. Enjoy this access (it is by invite only), and continue to be the awesome leader you are!",
	"existing_user_msg":"Glad to have you back! What would you like to do today?"
}');
INSERT INTO organization (description, full_name, tenant_id, unique_name, logo_path, domain_name, settings) VALUES ('Talengin','Talengin','605ee695-bb1b-4625-8d32-652c8575b72e','talengin','assets/img/talengin.jpeg','talengin',
'{
    "contact_email": "contact@talengin.com",
    "logo_path": "assets/img/talengin.jpeg",
    "copy_right": "Copyright © 2018 Talengin",
    "title": "Talengin",
	"new_user_msg":"Support your success. If you have any feedback, write to us contact@talengin.com. Enjoy this access (it is by invite only), and continue to be the awesome leader you are!",
	"existing_user_msg":"Glad to have you back! What would you like to do today?"
}');


INSERT INTO "user" (user_id, email, password_hash, salt, created_ip, created_datetime, last_login_ip, last_login_datetime, login_ip, disabled, disabled_reason, disabled_internal_reason, login_try, locked, locked_datetime, tenant_id, is_admin, login_datetime, full_name, is_active) VALUES (1, 'suresh@kanassociates.com', '4fV9jdU7IR292', '4fa0029d-e8ef-441e-b404-bf49277135b0', '127.0.0.1', '2018-03-21 12:32:21.558904', '::1', '2018-04-18 09:33:48.436314', '192.168.1.168', NULL, NULL, NULL, 0, false, NULL, 'f039d492-a55e-4fad-8a03-d77311ee8891', false, '2018-04-18 09:51:50.394504', 'Suresh M', true);
INSERT INTO "user" (user_id, email, password_hash, salt, created_ip, created_datetime, last_login_ip, last_login_datetime, login_ip, disabled, disabled_reason, disabled_internal_reason, login_try, locked, locked_datetime, tenant_id, is_admin, login_datetime, full_name, is_active) VALUES (2, 'jeff@kanassociates.com', '02.yfsIQizutc', '02d20e80-3551-4558-ad77-c319720f768b', '127.0.0.1', '2018-04-04 08:55:05.611848', NULL, NULL, NULL, NULL, NULL, NULL, 0, true, '2018-04-10 05:29:46.201961+00', 'f039d492-a55e-4fad-8a03-d77311ee8891', false, NULL, 'Jeff Summer', true);
INSERT INTO "user" (user_id, email, password_hash, salt, created_ip, created_datetime, last_login_ip, last_login_datetime, login_ip, disabled, disabled_reason, disabled_internal_reason, login_try, locked, locked_datetime, tenant_id, is_admin, login_datetime, full_name, is_active) VALUES (3, 'suresh@talengin.com', '4fV9jdU7IR292', '4fa0029d-e8ef-441e-b404-bf49277135b0', '127.0.0.1', '2018-03-21 12:32:21.558904', '::1', '2018-04-18 09:33:48.436314', '192.168.1.168', NULL, NULL, NULL, 0, false, NULL, '605ee695-bb1b-4625-8d32-652c8575b72e', false, '2018-04-18 09:51:50.394504', 'Suresh M', true);
INSERT INTO "user" (user_id, email, password_hash, salt, created_ip, created_datetime, last_login_ip, last_login_datetime, login_ip, disabled, disabled_reason, disabled_internal_reason, login_try, locked, locked_datetime, tenant_id, is_admin, login_datetime, full_name, is_active) VALUES (4, 'jeff@talengin.com', '02.yfsIQizutc', '02d20e80-3551-4558-ad77-c319720f768b', '127.0.0.1', '2018-04-04 08:55:05.611848', NULL, NULL, NULL, NULL, NULL, NULL, 0, true, '2018-04-10 05:29:46.201961+00', '605ee695-bb1b-4625-8d32-652c8575b72e', false, NULL, 'Jeff Summer', true);
INSERT INTO "user" (user_id, email, password_hash, salt, created_ip, created_datetime, last_login_ip, last_login_datetime, login_ip, disabled, disabled_reason, disabled_internal_reason, login_try, locked, locked_datetime, tenant_id, is_admin, login_datetime, full_name, is_active) VALUES (5, 'suresh@progenics.com', '4fV9jdU7IR292', '4fa0029d-e8ef-441e-b404-bf49277135b0', '127.0.0.1', '2018-03-21 12:32:21.558904', '::1', '2018-04-18 09:33:48.436314', '192.168.1.168', NULL, NULL, NULL, 0, false, NULL, '12bd322d-0dfd-4c94-9319-dccd8133bd6f', false, '2018-04-18 09:51:50.394504', 'Suresh M', true);
INSERT INTO "user" (user_id, email, password_hash, salt, created_ip, created_datetime, last_login_ip, last_login_datetime, login_ip, disabled, disabled_reason, disabled_internal_reason, login_try, locked, locked_datetime, tenant_id, is_admin, login_datetime, full_name, is_active) VALUES (6, 'jeff@progenics.com', '02.yfsIQizutc', '02d20e80-3551-4558-ad77-c319720f768b', '127.0.0.1', '2018-04-04 08:55:05.611848', NULL, NULL, NULL, NULL, NULL, NULL, 0, true, '2018-04-10 05:29:46.201961+00', '12bd322d-0dfd-4c94-9319-dccd8133bd6f', false, NULL, 'Jeff Summer', true);
INSERT INTO "user" (user_id, email, password_hash, salt, created_ip, created_datetime, last_login_ip, last_login_datetime, login_ip, disabled, disabled_reason, disabled_internal_reason, login_try, locked, locked_datetime, tenant_id, is_admin, login_datetime, full_name, is_active) VALUES (8, 'mahesh@solutionchamps.com', '41q9K888doXQo', '41e53d62-502f-4d84-bfc3-d609e9464b70', '127.0.0.1', '2018-05-09 16:40:42.057389', NULL, NULL, '::1', NULL, NULL, NULL, 0, false, NULL, 'f039d492-a55e-4fad-8a03-d77311ee8891', true, '2018-05-09 16:41:01.67234', 'mahesh', true);


INSERT INTO section (name, logo_path, title, tenant_id, id, is_active, is_enabled, sort_order_id) VALUES ('onboarding-your-talent', 'assets/img/Onboarding_Your_Talent.png', 'Onboarding your Talent', 'f039d492-a55e-4fad-8a03-d77311ee8891', 2, true, true, 2);
INSERT INTO section (name, logo_path, title, tenant_id, id, is_active, is_enabled, sort_order_id) VALUES ('cool-tools-for-your-use', 'assets/img/Cool_Tools.png', 'Cool tools for your use', 'f039d492-a55e-4fad-8a03-d77311ee8891', 4, true, true, 4);
INSERT INTO section (name, logo_path, title, tenant_id, id, is_active, is_enabled, sort_order_id) VALUES ('developing-yourself-and-others', 'assets/img/Developing_Yourself_Others.png', 'Developing yourself & Others', 'f039d492-a55e-4fad-8a03-d77311ee8891', 3, true, false, 3);
INSERT INTO section (name, logo_path, title, tenant_id, id, is_active, is_enabled, sort_order_id) VALUES ('recruitment-and-interview', 'assets/img/Recruitment_Interviewing.png', 'Recruitment & Interviewing', 'f039d492-a55e-4fad-8a03-d77311ee8891', 1, true, true, 1);

INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('team-dynamics', 'Team Dynamics', 'Team Dynamics', 4, '2018-03-26 09:54:32.782763', 1, 'f039d492-a55e-4fad-8a03-d77311ee8891', false, 6, true, 3);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('managing', 'Managing', 'Managing', 4, '2018-03-26 09:54:32.782763', 1, 'f039d492-a55e-4fad-8a03-d77311ee8891', false, 7, true, 4);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('forms', 'Docket', 'Forms', 1, '2018-04-02 12:43:25.405284', 1, 'f039d492-a55e-4fad-8a03-d77311ee8891', true, 8, true, 1);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('tool-and-resources', 'Tips & Resources', 'Tips & Resources', 1, '2018-03-24 06:59:29.21383', 1, 'f039d492-a55e-4fad-8a03-d77311ee8891', true, 1, true, 2);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('forms', 'Docket', 'Forms', 2, '2018-04-02 13:16:54.925247', 1, 'f039d492-a55e-4fad-8a03-d77311ee8891', true, 9, true, 1);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('tool-and-resources', 'Tips & Resources', 'Tips & Resources', 2, '2018-03-24 07:00:18.964826', 2, 'f039d492-a55e-4fad-8a03-d77311ee8891', true, 2, true, 2);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('competency-based-learnings', 'Competency based learnings', 'Competency based learnings', 3, '2018-03-26 09:46:27.591229', 1, 'f039d492-a55e-4fad-8a03-d77311ee8891', true, 3, false, 1);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('online-courses', 'Online Courses', 'Online Courses', 3, '2018-03-26 09:46:39.566618', 1, 'f039d492-a55e-4fad-8a03-d77311ee8891', true, 4, false, 2);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('other-development-plans', 'Other Development Plans', 'Other Development Plans', 3, '2018-03-26 09:46:39.566618', 1, 'f039d492-a55e-4fad-8a03-d77311ee8891', true, 5, false, 3);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('forms', 'Docket', 'Forms', 4, '2018-04-02 13:58:16.028052', 1, 'f039d492-a55e-4fad-8a03-d77311ee8891', true, 10, true, 1);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('tool-and-resources', 'Tips & Resources', 'Tips & Resources', 4, '2018-04-28 07:00:18.964826', 1, 'f039d492-a55e-4fad-8a03-d77311ee8891', true, 11, true, 2);

INSERT INTO resource (name, title, category_id, resource_type, description, id, property, is_active, sort_order_id) VALUES ('checklist', 'CheckList Guide', 2, 'PDF', ' ', 3, '{ "path": "/assets/files/Checklist.pdf" }', true, 1);
INSERT INTO resource (name, title, category_id, resource_type, description, id, property, is_active, sort_order_id) VALUES ('30-60-90', '30-60-90 Plan Guide', 2, 'PDF', ' ', 4, '{ "path": "/assets/files/30-60-90-Plan.pdf"}', true, 2);
INSERT INTO resource (name, title, category_id, resource_type, description, id, property, is_active, sort_order_id) VALUES ('sml', 'Planning (SML)', 11, 'PDF', ' ', 7, '{"path": "/assets/files/SML.pdf"}', true, 1);
INSERT INTO resource (name, title, category_id, resource_type, description, id, property, is_active, sort_order_id) VALUES ('bei-guide', 'BEI Guide', 1, 'PDF', ' ', 1, '{"path":"/assets/files/BEI_Hand_out.pdf"}', true, 1);
INSERT INTO resource (name, title, category_id, resource_type, description, id, property, is_active, sort_order_id) VALUES ('conducting-effective-interviews', 'Conducting Effective Interviews', 1, 'PDF', ' ', 2, '{"path":"/assets/files/Conducting_Effective_Interviews.pdf"}', true, 2);



INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, is_active, sort_order_id) VALUES ('interview-assessment-template', 'Interview Assessment Template', 'As leaders when you interview candidates, it is important you document your experiences and outcomes. This form helps you with just that.', '2018-03-22 10:04:50.265662', 1, 'form', 3, 8, true, 3);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, is_active, sort_order_id) VALUES ('checklist', 'Checklist', 'Joining a new company is, at times, overwhelming for anyone. Imagine providing your new colleagues the experiences during (& even before) they join. Here is a simple checklist of suggestions for you, as a leader.', '2018-03-26 09:37:11.405134', 1, 'form', 5, 9, true, 1);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, is_active, sort_order_id) VALUES ('30-60-90-day-plan', '30-60-90 Day Plan', 'Remember, your new colleagues always look for clarity and understanding expectations from them. A 30-60-90 day plan helps just with that. Tip : Keep it simple. Provide the support. Ensure you are encouraging them with the right opportunities for them to learn & network. It is now easy for you to create a 30-60-90 day plan.', '2018-03-26 09:37:27.78035', 1, 'form', 6, 9, true, 2);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, is_active, sort_order_id) VALUES ('goal-setting', 'Goal Setting', 'Goal Setting', '2018-03-26 09:50:56.305503', 1, 'goalsetting', 4, 10, false, 1);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, is_active, sort_order_id) VALUES ('planning-sml', 'Planning (SML)', 'A chart to details the list of activities on different time frames focusing on planning processes considering the time-sensitivity aspects also defines the input to achieve an expected outcomes', '2018-03-26 09:37:27.78035', 1, 'form', 7, 10, true, 2);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, is_active, sort_order_id) VALUES ('position-profile-template', 'Position Profile Template', 'The start to getting the right talent is to have clarity on what the person is expected to do. It is now easy for you to create a Position Profile (aka Job Description)', '2018-03-22 10:04:50.265662', 1, 'form', 1, 8, true, 1);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, is_active, sort_order_id) VALUES ('general-interview-template', 'General Interview Template', 'Interviews must be engaging, informative and must enable you as a leader to ensure you understand the candidate’s fitment to the role, company and culture. Here are some guidelines (& questions) to make the interview process more meaningful - for your potential talent. And you!!', '2018-03-22 10:04:50.265662', 1, 'form', 2, 8, true, 2);


INSERT INTO form_template (id, form_id, data, version_id, is_default, created_datetime, created_user_id, summary_fields) VALUES (2, 2, '[{
        "name": "name",
        "title": "Name of the candidate",
        "controlType": "text",
        "required": true,
        "colspan": 6,
        "row": 1
    },{
        "name": "knowabout",
        "title": "What do you know about Progenics",
        "subtitle":"How qualified and experienced is the candidate technically for this role? Whatareas would you like to highlight in terms of her/his technical skills? Where did you observe are the gaps?",
        "controlType": "textarea",
        "required": false,
        "colspan": 12,
        "row": 2
    }, {
        "name": "idealjob",
        "title": "Describe your ideal job",
        "controlType": "textarea",
        "required": false,
        "colspan": 12,
        "row": 3
    }, {
        "name": "aboutposition",
        "title": "What interests you most about this position?",
        "controlType": "textarea",
        "required": false,
        "colspan": 12,
        "row": 4
    }, {
        "name": "motivateswork",
        "title": "What motivates you to do your best work?",
        "controlType": "textarea",
        "required": false,
        "colspan": 12,
        "row": 5
    }, {
        "name": "frustration",
        "title": "What do you find most frustating at work?",
        "controlType": "textarea",
        "colspan": 12,
        "row": 6
    },{
        "name": "excited",
        "title": "Tell me about a project that got you really excited?",
        "controlType": "textarea",
        "colspan": 12,
        "row": 7
    },{
        "name": "bestcondition",
        "title": "Under what condition do you work best?",
        "controlType": "textarea",
        "colspan": 12,
        "row": 8
    },{
        "name": "lastposition",
        "title": "Tell me about your last position and what you did?",
        "controlType": "textarea",
        "colspan": 12,
        "row": 9
    },{
        "name": "correctedmistake",
        "title": "Tell me about the last time you made a mistake and how you corrected it?",
        "controlType": "textarea",
        "colspan": 12,
        "row": 9
    },{
        "name": "learnedprevious",
        "title": "What is the most important thing you learned at previous or in your current job?",
        "controlType": "textarea",
        "colspan": 12,
        "row": 9
    },{
        "name": "previouspositions",
        "title": "How have your previous positions prepared you for this one?",
        "controlType": "textarea",
        "colspan": 12,
        "row": 9
    },{
        "name": "upperlevelmanagement",
        "title": "How would you grade your ability to communicate with Upper level management, Customers, and/or peers?",
        "controlType": "textarea",
        "colspan": 12,
        "row": 9
    }]', 1, true, '2018-03-22 10:04:50.265662', 1, '[{"field" : "name", "title" : "Name of the candidate" }]');
INSERT INTO form_template (id, form_id, data, version_id, is_default, created_datetime, created_user_id, summary_fields) VALUES (4, 4, '{}', 1, true, '2018-03-26 11:51:02.481199', 1, NULL);
INSERT INTO form_template (id, form_id, data, version_id, is_default, created_datetime, created_user_id, summary_fields) VALUES (5, 5, '{}', 1, true, '2018-03-26 11:51:26.969229', 1, NULL);
INSERT INTO form_template (id, form_id, data, version_id, is_default, created_datetime, created_user_id, summary_fields) VALUES (3, 3, '[{"name":"email","title":"Email address","colspan":6,"required":true,"controlType":"text","row":1},{"name":"name","title":"Your Name","colspan":6,"required":true,"controlType":"text","row":2},{"name":"beinghired","title":"Position being hired for","colspan":6,"required":true,"controlType":"text","row":2},{"name":"interviewdate","title":"Date of interview","colspan":4,"required":true,"controlType":"date","row":3},{"name":"candidatename","title":"Name of the candidate","colspan":6,"required":true,"controlType":"text","row":3},{"name":"candidatelocation","title":"Candidate Location","colspan":6,"required":true,"controlType":"text","row":4},{"subtitle":"How did the interview go? Level of interest/enthusiasm from the candidate. What did/did not go well?","name":"interviewsummary","title":"Summary of the interview","colspan":12,"required":false,"controlType":"textarea","row":4},{"subtitle":"How qualified and experienced is the candidate technically for this role? What areas would you like to highlight in terms of her/his technical skills? Where did you observe are the gaps?","name":"purposeofposition","title":"Technical Assessment","colspan":12,"required":false,"controlType":"textarea","row":5},{"rows":[{"title":"Drive Vision and Purpose","options":["Excellent","Good","Moderate/Fair","Poor","Did not assess","Not essential for the role"],"name":"drivevision"},{"title":"Communicates Effectively","options":["Excellent","Good","Moderate/Fair","Poor","Did not assess","Not essential for the role"],"name":"communication"},{"title":"Strategic Mindset","options":["Excellent","Good","Moderate/Fair","Poor","Did not assess","Not essential for the role"],"name":"strategicmindset"},{"title":"Balances Stakeholders","options":["Excellent","Good","Moderate/Fair","Poor","Did not assess","Not essential for the role"],"name":"balancesstakeholders"},{"title":"Business Insight","options":["Excellent","Good","Moderate/Fair","Poor","Did not assess","Not essential for the role"],"name":"businessinsight"},{"title":"Plans and Aligns","options":["Excellent","Good","Moderate/Fair","Poor","Did not assess","Not essential for the role"],"name":"plansandaligns"},{"title":"Optimizes Work Processes","options":["Excellent","Good","Moderate/Fair","Poor","Did not assess","Not essential for the role"],"name":"optimizesworkprocesses"},{"title":"Drives Engagement","options":["Excellent","Good","Moderate/Fair","Poor","Did not assess","Not essential for the role"],"name":"drivesengagement"},{"title":"Decision Quality","options":["Excellent","Good","Moderate/Fair","Poor","Did not assess","Not essential for the role"],"name":"decisionquality"},{"title":"Tech Savvy","options":["Excellent","Good","Moderate/Fair","Poor","Did not assess","Not essential for the role"],"name":"techsavvy"},{"title":"Collaborates","options":["Excellent","Good","Moderate/Fair","Poor","Did not assess","Not essential for the role"],"name":"collaborates"},{"title":"Nimble Learning","options":["Excellent","Good","Moderate/Fair","Poor","Did not assess","Not essential for the role"],"name":"nimblelearning"},{"title":"Cultivates Innovation","options":["Excellent","Good","Moderate/Fair","Poor","Did not assess","Not essential for the role"],"name":"cultivatesinnovation"},{"title":"Situational Adaptability","options":["Excellent","Good","Moderate/Fair","Poor","Did not assess","Not essential for the role"],"name":"situationaladaptability"}],"subtitle":"Based on your discussion how would you evaluate the candidates competencies. You may want to use the Behavioural Event Interview (BEI) Guide having the list of questions.","name":"assessment","title":"How would you assess the candidate on the following Competencies?","colspan":12,"headers":["","Excellent","Good","Moderate/Fair","Poor","Did not assess","Not essential for the role"],"controlType":"assessment-table","row":6},{"subtitle":"Aspects around what was his/her strengths and essential for the role. Anything that is critical for the role but the candidate did/did not possess ?","name":"competencieshighlight","title":"Based on the above Competencies, is there anything you would like to highlight ?","colspan":12,"required":false,"controlType":"textarea","row":7},{"name":"isProceed","title":"What is your decision regarding the candidate?","colspan":6,"controlType":"radio","options":[{"text":"Not to proceed","value":"NotToProceed"},{"text":"Proceed with next round","value":"nextRound"}],"row":8},{"name":"decision","title":"Your rationale behind the decision","colspan":12,"required":false,"controlType":"textarea","row":9}]', 1, false, '2018-03-22 10:04:50.265662', 1, NULL);
INSERT INTO form_template (id, form_id, data, version_id, is_default, created_datetime, created_user_id, summary_fields) VALUES (1, 1, '
[{
        "name": "name",
        "title": "Your Name",
        "controlType": "text",
        "required": true,
        "colspan": 6,
        "row": 1
    }, {
        "name": "department",
        "title": "Your Department",
        "controlType": "text",
        "required": true,
        "colspan": 6,
        "row": 2
    }, {
        "name": "positiontitle",
        "title": "Position title (of the role you are hiring)",
        "controlType": "text",
        "required": true,
        "colspan": 6,
        "row": 2
    }, {
        "name": "purposeofposition",
        "title": "Purpose of the position (Summary/headline of objectives of the position)",
        "controlType": "textarea",
        "required": true,
        "colspan": 12,
        "row": 2
    }, {
        "name": "location",
        "title": "Location",
        "controlType": "select",
        "options": [{
            "text": "NYC",
            "value": 1
        },{
            "text": "Lund",
            "value": 2
        }, {
            "text": "Others (Please fill 5A)",
            "value": 3
        }],
        "showEmpty": true,
        "colspan": 4,
        "row": 4
    },{
        "name": "otherlocation",
        "title": "Other Location",
        "controlType": "text",
        "required": false,
        "colspan": 4,
        "row": 4
    }, {
        "name": "typeofcontract",
        "title": "Type of Contract",
        "controlType": "select",
        "options": [{
            "text": "Permanent Employment",
            "value": 1
        }, {
            "text": "Contract",
            "value": 2
        },{
            "text": "Internship",
            "value": 3
        }],
        "showEmpty": true,
        "colspan": 4,
        "row": 5
    },
    {
        "name": "keyduties",
        "title": "Key Duties & Responsibilities : (Please be specific; atleast 6-7 bullets)",
        "controlType": "textarea",
        "required": true,
        "colspan": 12,
        "row": 6
    },
    {
        "name": "keyresults",
        "title": "Key Result Areas (what will be the performance expectations)",
        "controlType": "textarea",
        "required": true,
        "colspan": 12,
        "row": 7
    },

    {
        "name": "positionreport",
        "title": "Who will this position report to ",
        "controlType": "text",
        "required": true,
        "colspan": 6,
        "row": 8
    },{
        "name": "directreportees",
        "title": "Who will be the direct reportees",
        "controlType": "text",
        "required": false,
        "colspan": 6,
        "row": 8
    },{
        "name": "qualifications",
        "title": "Qualifications",
        "controlType": "text",
        "required": true,
        "colspan": 6,
        "row": 9
    },{
        "name": "experiencerange",
        "title": "Experience range (in years)",
        "controlType": "text",
        "required": true,
        "colspan": 6,
        "row": 9
    },
    {
        "name": "desiredexperience",
        "title": "Desired experiences or specific skill sets",
        "controlType": "text",
        "required": true,
        "colspan": 6,
        "row": 10
    },
    {
        "name": "competencies",
        "title": "Competencies (Choose 5 from the list)",
        "controlType": "checkbox",
        "required": true,
        "row": 11,
        "colspan": 6,
        "options": [{
            "text": "Drives Vision and Purpose",
            "value": 1
        },
        {
            "text": "Communicates Effectively",
            "value": 2
        },
        {
            "text": "Strategic Mindset",
            "value": 3
        }, 
        {
            "text": "Balances Stakeholders",
            "value": 4
        },
        {
            "text": "Business Insight",
            "value": 5
        },
        {
            "text": "Plans and Aligns",
            "value": 6
        },
        {
            "text": "Optimizes Work Processes",
            "value": 7
        }, {
            "text": "Drives Engagement",
            "value": 8
        },
        {
            "text": "Decision Quality",
            "value": 9
        },
        {
            "text": "Tech Savvy",
            "value": 10
        }, 
        {
            "text": "Collaborates",
            "value": 11
        },
        {
            "text": "Nimble Learning",
            "value": 12
        },
        {
            "text": "Cultivates Innovation",
            "value": 13
        },
        {
            "text": "Situational Adaptability",
            "value": 14
        }]
    },
    {
        "name": "additionalcomments",
        "title": "Additional Comments",
        "controlType": "textarea",
        "required": false,
        "colspan": 12,
        "row": 12
    }]', 1, true, '2018-03-22 10:04:50.265662', 1, '[{"field" : "name", "title" : "Name of the candidate" }]');



  

SELECT setval('user_user_id_seq', coalesce((select max(user_id) from "user"), 1), true); 
SELECT setval('section_id_seq', coalesce((select max(id) from section), 1), true); 
SELECT setval('category_id_seq', coalesce((select max(id) from category), 1), true); 
SELECT setval('resource_id_seq', coalesce((select max(id) from resource), 1), true); 
SELECT setval('form_id_seq1', coalesce((select max(id) from form), 1), true); 
SELECT setval('form_template_id_seq', coalesce((select max(id) from form_template), 1), true); 