/* Replace with your SQL commands */

INSERT INTO section (name, logo_path, title, tenant_id, id, is_active, is_enabled, sort_order_id) VALUES ('onboarding-your-talent', 'assets/img/Onboarding_Your_Talent.png', 'Onboarding your Talent', '12bd322d-0dfd-4c94-9319-dccd8133bd6f', 5, true, true, 2);
INSERT INTO section (name, logo_path, title, tenant_id, id, is_active, is_enabled, sort_order_id) VALUES ('cool-tools-for-your-use', 'assets/img/Cool_Tools.png', 'Cool tools for your use', '12bd322d-0dfd-4c94-9319-dccd8133bd6f', 6, true, true, 4);
INSERT INTO section (name, logo_path, title, tenant_id, id, is_active, is_enabled, sort_order_id) VALUES ('developing-yourself-and-others', 'assets/img/Developing_Yourself_Others.png', 'Developing yourself & Others', '12bd322d-0dfd-4c94-9319-dccd8133bd6f', 7, true, false, 3);
INSERT INTO section (name, logo_path, title, tenant_id, id, is_active, is_enabled, sort_order_id) VALUES ('recruitment-and-interview', 'assets/img/Recruitment_Interviewing.png', 'Recruitment & Interviewing', '12bd322d-0dfd-4c94-9319-dccd8133bd6f', 8, true, true, 1);
INSERT INTO section (name, logo_path, title, tenant_id, id, is_active, is_enabled, sort_order_id) VALUES ('onboarding-your-talent', 'assets/img/Onboarding_Your_Talent.png', 'Onboarding your Talent', '605ee695-bb1b-4625-8d32-652c8575b72e', 9, true, true, 2);
INSERT INTO section (name, logo_path, title, tenant_id, id, is_active, is_enabled, sort_order_id) VALUES ('cool-tools-for-your-use', 'assets/img/Cool_Tools.png', 'Cool tools for your use', '605ee695-bb1b-4625-8d32-652c8575b72e', 10, true, true, 4);
INSERT INTO section (name, logo_path, title, tenant_id, id, is_active, is_enabled, sort_order_id) VALUES ('developing-yourself-and-others', 'assets/img/Developing_Yourself_Others.png', 'Developing yourself & Others', '605ee695-bb1b-4625-8d32-652c8575b72e', 11, true, false, 3);
INSERT INTO section (name, logo_path, title, tenant_id, id, is_active, is_enabled, sort_order_id) VALUES ('recruitment-and-interview', 'assets/img/Recruitment_Interviewing.png', 'Recruitment & Interviewing', '605ee695-bb1b-4625-8d32-652c8575b72e', 12, true, true, 1);


INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('team-dynamics', 'Team Dynamics', 'Team Dynamics', 6, '2018-03-26 09:54:32.782763', 1, '12bd322d-0dfd-4c94-9319-dccd8133bd6f', false, 12, true, 3);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('managing', 'Managing', 'Managing', 6, '2018-03-26 09:54:32.782763', 1, '12bd322d-0dfd-4c94-9319-dccd8133bd6f', false, 13, true, 4);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('forms', 'Docket', 'Forms', 8, '2018-04-02 12:43:25.405284', 1, '12bd322d-0dfd-4c94-9319-dccd8133bd6f', true, 14, true, 1);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('forms', 'Docket', 'Forms', 5, '2018-04-02 13:16:54.925247', 1, '12bd322d-0dfd-4c94-9319-dccd8133bd6f', true, 16, true, 1);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('competency-based-learnings', 'Competency based learnings', 'Competency based learnings', 7, '2018-03-26 09:46:27.591229', 1, '12bd322d-0dfd-4c94-9319-dccd8133bd6f', true, 18, false, 1);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('online-courses', 'Online Courses', 'Online Courses', 7, '2018-03-26 09:46:39.566618', 1, '12bd322d-0dfd-4c94-9319-dccd8133bd6f', true, 19, false, 2);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('other-development-plans', 'Other Development Plans', 'Other Development Plans', 7, '2018-03-26 09:46:39.566618', 1, '12bd322d-0dfd-4c94-9319-dccd8133bd6f', true, 20, false, 3);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('forms', 'Docket', 'Forms', 6, '2018-04-02 13:58:16.028052', 1, '12bd322d-0dfd-4c94-9319-dccd8133bd6f', true, 21, true, 1);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('tool-and-resources', 'Tips & Resources', 'Tips & Resources', 6, '2018-04-28 07:00:18.964826', 1, '12bd322d-0dfd-4c94-9319-dccd8133bd6f', true, 22, true, 2);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('managing', 'Managing', 'Managing', 4, '2018-03-26 09:54:32.782763', 1, '12bd322d-0dfd-4c94-9319-dccd8133bd6f', false, 24, true, 4);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('forms', 'Docket', 'Forms', 12, '2018-04-02 12:43:25.405284', 1, '605ee695-bb1b-4625-8d32-652c8575b72e', true, 25, true, 1);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('tool-and-resources', 'Tips & Resources', 'Tips & Resources', 12, '2018-03-24 06:59:29.21383', 1, '605ee695-bb1b-4625-8d32-652c8575b72e', true, 26, true, 2);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('competency-based-learnings', 'Competency based learnings', 'Competency based learnings', 11, '2018-03-26 09:46:27.591229', 1, '605ee695-bb1b-4625-8d32-652c8575b72e', true, 29, false, 1);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('online-courses', 'Online Courses', 'Online Courses', 11, '2018-03-26 09:46:39.566618', 1, '605ee695-bb1b-4625-8d32-652c8575b72e', true, 30, false, 2);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('other-development-plans', 'Other Development Plans', 'Other Development Plans', 11, '2018-03-26 09:46:39.566618', 1, '605ee695-bb1b-4625-8d32-652c8575b72e', true, 31, false, 3);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('team-dynamics', 'Team Dynamics', 'Team Dynamics', 10, '2018-03-26 09:54:32.782763', 1, '605ee695-bb1b-4625-8d32-652c8575b72e', false, 23, true, 3);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('forms', 'Docket', 'Forms', 9, '2018-04-02 13:16:54.925247', 1, '605ee695-bb1b-4625-8d32-652c8575b72e', true, 27, true, 1);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('tool-and-resources', 'Tips & Resources', 'Tips & Resources', 9, '2018-03-24 07:00:18.964826', 2, '605ee695-bb1b-4625-8d32-652c8575b72e', true, 28, true, 2);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('forms', 'Docket', 'Forms', 10, '2018-04-02 13:58:16.028052', 1, '605ee695-bb1b-4625-8d32-652c8575b72e', true, 32, true, 1);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('tool-and-resources', 'Tips & Resources', 'Tips & Resources', 10, '2018-04-28 07:00:18.964826', 1, '605ee695-bb1b-4625-8d32-652c8575b72e', true, 33, true, 2);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('tool-and-resources', 'Tips & Resources', 'Tips & Resources', 5, '2018-03-24 06:59:29.21383', 1, '12bd322d-0dfd-4c94-9319-dccd8133bd6f', true, 15, true, 2);
INSERT INTO category (name, title, description, section_id, created_datetime, created_user_id, tenant_id, is_active, id, is_enabled, sort_order_id) VALUES ('tool-and-resources', 'Tips & Resources', 'Tips & Resources', 8, '2018-03-24 07:00:18.964826', 2, '12bd322d-0dfd-4c94-9319-dccd8133bd6f', true, 17, true, 2);


INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, sort_order_id, is_active) VALUES ('interview-assessment-template', 'Interview Assessment Template', 'As leaders when you interview candidates, it is important you document your experiences and outcomes. This form helps you with just that.', '2018-03-22 10:04:50.265662', 1, 'form', 8, 14, 3, true);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, sort_order_id, is_active) VALUES ('checklist', 'Checklist', 'Joining a new company is, at times, overwhelming for anyone. Imagine providing your new colleagues the experiences during (& even before) they join. Here is a simple checklist of suggestions for you, as a leader.', '2018-03-26 09:37:11.405134', 1, 'form', 9, 16, 1, true);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, sort_order_id, is_active) VALUES ('30-60-90-day-plan', '30-60-90 Day Plan', 'Remember, your new colleagues always look for clarity and understanding expectations from them. A 30-60-90 day plan helps just with that. Tip : Keep it simple. Provide the support. Ensure you are encouraging them with the right opportunities for them to learn & network. It is now easy for you to create a 30-60-90 day plan.', '2018-03-26 09:37:27.78035', 1, 'form', 10, 16, 2, true);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, sort_order_id, is_active) VALUES ('goal-setting', 'Goal Setting', 'Goal Setting', '2018-03-26 09:50:56.305503', 1, 'goalsetting', 11, 10, 1, false);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, sort_order_id, is_active) VALUES ('planning-sml', 'Planning (SML)', 'A chart to details the list of activities on different time frames focusing on planning processes considering the time-sensitivity aspects also defines the input to achieve an expected outcomes', '2018-03-26 09:37:27.78035', 1, 'form', 12, 21, 2, true);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, sort_order_id, is_active) VALUES ('position-profile-template', 'Position Profile Template', 'The start to getting the right talent is to have clarity on what the person is expected to do. It is now easy for you to create a Position Profile (aka Job Description)', '2018-03-22 10:04:50.265662', 1, 'form', 13, 14, 1, true);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, sort_order_id, is_active) VALUES ('general-interview-template', 'General Interview Template', 'Interviews must be engaging, informative and must enable you as a leader to ensure you understand the candidate’s fitment to the role, company and culture. Here are some guidelines (& questions) to make the interview process more meaningful - for your potential talent. And you!!', '2018-03-22 10:04:50.265662', 1, 'form', 14, 14, 2, true);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, sort_order_id, is_active) VALUES ('goal-setting', 'Goal Setting', 'Goal Setting', '2018-03-26 09:50:56.305503', 1, 'goalsetting', 18, 10, 1, false);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, sort_order_id, is_active) VALUES ('planning-sml', 'Planning (SML)', 'A chart to details the list of activities on different time frames focusing on planning processes considering the time-sensitivity aspects also defines the input to achieve an expected outcomes', '2018-03-26 09:37:27.78035', 1, 'form', 19, 32, 2, true);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, sort_order_id, is_active) VALUES ('interview-assessment-template', 'Interview Assessment Template', 'As leaders when you interview candidates, it is important you document your experiences and outcomes. This form helps you with just that.', '2018-03-22 10:04:50.265662', 1, 'form', 22, 25, 3, true);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, sort_order_id, is_active) VALUES ('checklist', 'Checklist', 'Joining a new company is, at times, overwhelming for anyone. Imagine providing your new colleagues the experiences during (& even before) they join. Here is a simple checklist of suggestions for you, as a leader.', '2018-03-26 09:37:11.405134', 1, 'form', 23, 27, 1, true);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, sort_order_id, is_active) VALUES ('30-60-90-day-plan', '30-60-90 Day Plan', 'Remember, your new colleagues always look for clarity and understanding expectations from them. A 30-60-90 day plan helps just with that. Tip : Keep it simple. Provide the support. Ensure you are encouraging them with the right opportunities for them to learn & network. It is now easy for you to create a 30-60-90 day plan.', '2018-03-26 09:37:27.78035', 1, 'form', 24, 27, 2, true);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, sort_order_id, is_active) VALUES ('goal-setting', 'Goal Setting', 'Goal Setting', '2018-03-26 09:50:56.305503', 1, 'goalsetting', 25, 10, 1, false);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, sort_order_id, is_active) VALUES ('position-profile-template', 'Position Profile Template', 'The start to getting the right talent is to have clarity on what the person is expected to do. It is now easy for you to create a Position Profile (aka Job Description)', '2018-03-22 10:04:50.265662', 1, 'form', 27, 25, 1, true);
INSERT INTO form (name, title, description, created_datetime, created_user_id, form_type, id, category_id, sort_order_id, is_active) VALUES ('general-interview-template', 'General Interview Template', 'Interviews must be engaging, informative and must enable you as a leader to ensure you understand the candidate’s fitment to the role, company and culture. Here are some guidelines (& questions) to make the interview process more meaningful - for your potential talent. And you!!', '2018-03-22 10:04:50.265662', 1, 'form', 28, 25, 2, true);


INSERT INTO form_template (form_id, data, version_id, is_default, created_datetime, created_user_id, summary_fields, sort_order_id) VALUES (27, '[{
    settings: {
        hideActionButtons: [
            ''print'', ''mail''
        ]
    },
    fields: [
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''name'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Your Name'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''department'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Your Department'',
                        required: true
                    }
                },
                {
                    key: ''positiontitle'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Position title (of the role you are hiring)'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''purposeofposition'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Purpose of the position (Summary/headline of objectives of the position)'',
                        required: true,
                        rows: 5
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''location'',
                    type: ''select'',
                    className: ''col-lg-4'',
                    templateOptions: {
                        label: ''Location'',
                        required: true,
                        placeholder: ''Choose'',
                        options: [
                            { label: ''NYC'', value: 0 },
                            { label: ''Lund'', value: 1 },
                            { label: ''Others (Please fill 5A)'', value: 2 }]
                    },
                    defaultValue: '''',
                },
                {
                    key: ''otherlocation'',
                    type: ''input'',
                    className: ''col-lg-4'',
                    templateOptions: {
                        label: ''Other Location'',
                        required: true,
                    },
                    hideExpression: ''model.location !== "2"'',
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''typeofcontract'',
                    type: ''select'',
                    className: ''col-lg-4'',
                    templateOptions: {
                        label: ''Type of Contract'',
                        placeholder: ''Choose'',
                        required: true,
                        options: [
                            { label: ''Permanent Employment'', value: 0 },
                            { label: ''Contract'', value: 1 },
                            { label: ''Internship'', value: 2 }],
                    },
                    defaultValue: '''',
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''keyduties'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Key Duties & Responsibilities : (Please be specific; atleast 6-7 bullets)'',
                        required: true,
                        rows: 5
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''keyresults'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Key Result Areas (what will be the performance expectations)'',
                        required: true,
                        rows: 5
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''positionreport'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Who will this position report to'',
                        required: true
                    }
                },
                {
                    key: ''directreportees'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Who will be the direct reportees''
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''qualifications'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Qualifications'',
                        required: true
                    }
                },
                {
                    key: ''experiencerange'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Experience range (in years)'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''desiredexperience'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Desired experiences or specific skill sets'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''competencies'',
                    type: ''multicheckbox'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Competencies (Choose 5 from the list)'',
                        required: true,
                        min: 5,
                        options: [
                            { ''key'': ''drivesvision'', ''value'': ''Drives Vision and Purpose'' },
                            { ''key'': ''communication'', ''value'': ''Communicates Effectively'' },
                            { ''key'': ''strategic'', ''value'': ''Strategic Mindset'' },
                            { ''key'': ''balanced'', ''value'': ''Balances Stakeholders'' },
                            { ''key'': ''business-insight'', ''value'': ''Business Insight'' },
                            { ''key'': ''plans'', ''value'': ''Plans and Aligns'' },
                            { ''key'': ''optimized'', ''value'': ''Optimizes Work Processes'' },
                            { ''key'': ''drives'', ''value'': ''Drives Engagement'' },
                            { ''key'': ''decision'', ''value'': ''Decision Quality'' },
                            { ''key'': ''tech-savy'', ''value'': ''Tech Savvy'' },
                            { ''key'': ''collab'', ''value'': ''Collaborates'' },
                            { ''key'': ''learning'', ''value'': ''Nimble Learning'' },
                            { ''key'': ''innovation'', ''value'': ''Cultivates Innovation'' },
                            { ''key'': ''adaptability'', ''value'': ''Situational Adaptability'' }
                        ]
                    },
                    validators: {
                        ip: {
                            expression: (c) => {
                                return Object.keys(c.value)
                                    .filter(key => !!c.value[key])
                                    .length > 4;
                            },
                            message: (error, field) => `Choose at least 5 competencies`,
                        },
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''additionalcomments'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Additional Comments'',
                        rows: 10
                    }
                }
            ]
        }
    ]
}]', 2, true, '2018-04-24 10:32:52.952296', 1, '[{"field":"positiontitle","title":"Position"}]', 1);
INSERT INTO form_template (form_id, data, version_id, is_default, created_datetime, created_user_id, summary_fields, sort_order_id) VALUES (13, '[{
    settings: {
        hideActionButtons: [
            ''print'', ''mail''
        ]
    },
    fields: [
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''name'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Your Name'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''department'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Your Department'',
                        required: true
                    }
                },
                {
                    key: ''positiontitle'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Position title (of the role you are hiring)'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''purposeofposition'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Purpose of the position (Summary/headline of objectives of the position)'',
                        required: true,
                        rows: 5
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''location'',
                    type: ''select'',
                    className: ''col-lg-4'',
                    templateOptions: {
                        label: ''Location'',
                        required: true,
                        placeholder: ''Choose'',
                        options: [
                            { label: ''NYC'', value: 0 },
                            { label: ''Lund'', value: 1 },
                            { label: ''Others (Please fill 5A)'', value: 2 }]
                    },
                    defaultValue: '''',
                },
                {
                    key: ''otherlocation'',
                    type: ''input'',
                    className: ''col-lg-4'',
                    templateOptions: {
                        label: ''Other Location'',
                        required: true,
                    },
                    hideExpression: ''model.location !== "2"'',
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''typeofcontract'',
                    type: ''select'',
                    className: ''col-lg-4'',
                    templateOptions: {
                        label: ''Type of Contract'',
                        placeholder: ''Choose'',
                        required: true,
                        options: [
                            { label: ''Permanent Employment'', value: 0 },
                            { label: ''Contract'', value: 1 },
                            { label: ''Internship'', value: 2 }],
                    },
                    defaultValue: '''',
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''keyduties'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Key Duties & Responsibilities : (Please be specific; atleast 6-7 bullets)'',
                        required: true,
                        rows: 5
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''keyresults'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Key Result Areas (what will be the performance expectations)'',
                        required: true,
                        rows: 5
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''positionreport'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Who will this position report to'',
                        required: true
                    }
                },
                {
                    key: ''directreportees'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Who will be the direct reportees''
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''qualifications'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Qualifications'',
                        required: true
                    }
                },
                {
                    key: ''experiencerange'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Experience range (in years)'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''desiredexperience'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Desired experiences or specific skill sets'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''competencies'',
                    type: ''multicheckbox'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Competencies (Choose 5 from the list)'',
                        required: true,
                        min: 5,
                        options: [
                            { ''key'': ''drivesvision'', ''value'': ''Drives Vision and Purpose'' },
                            { ''key'': ''communication'', ''value'': ''Communicates Effectively'' },
                            { ''key'': ''strategic'', ''value'': ''Strategic Mindset'' },
                            { ''key'': ''balanced'', ''value'': ''Balances Stakeholders'' },
                            { ''key'': ''business-insight'', ''value'': ''Business Insight'' },
                            { ''key'': ''plans'', ''value'': ''Plans and Aligns'' },
                            { ''key'': ''optimized'', ''value'': ''Optimizes Work Processes'' },
                            { ''key'': ''drives'', ''value'': ''Drives Engagement'' },
                            { ''key'': ''decision'', ''value'': ''Decision Quality'' },
                            { ''key'': ''tech-savy'', ''value'': ''Tech Savvy'' },
                            { ''key'': ''collab'', ''value'': ''Collaborates'' },
                            { ''key'': ''learning'', ''value'': ''Nimble Learning'' },
                            { ''key'': ''innovation'', ''value'': ''Cultivates Innovation'' },
                            { ''key'': ''adaptability'', ''value'': ''Situational Adaptability'' }
                        ]
                    },
                    validators: {
                        ip: {
                            expression: (c) => {
                                return Object.keys(c.value)
                                    .filter(key => !!c.value[key])
                                    .length > 4;
                            },
                            message: (error, field) => `Choose at least 5 competencies`,
                        },
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''additionalcomments'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Additional Comments'',
                        rows: 10
                    }
                }
            ]
        }
    ]
}]', 2, true, '2018-04-24 10:32:52.952296', 1, '[{"field":"positiontitle","title":"Position"}]', 1);
INSERT INTO form_template (form_id, data, version_id, is_default, created_datetime, created_user_id, summary_fields, sort_order_id) VALUES (14, '[{
    settings: {
        hideActionButtons: [
            ''print'', ''mail''
        ]
    },fields: [{
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''name'',
                type: ''input'',
                className: ''col-lg-6'',
                templateOptions: {
                    label: ''Your Name'',
                    required: true
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''aboutprogenics'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''What do you know about Progenics'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''idealjob'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''Describe your ideal job'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''aboutthisposition'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''What interests you most about this position?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''motivatesyourbestwork'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''What motivates you to do your best work?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''mostfrustratingwork'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''What do you find most frustrating at work?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''projectyoureallyexcited'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''Tell me about a project that got you really excited?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''conditionyouworkbest'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''Under what condition do you work best?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''aboutyourlastposition'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''Tell me about your last position and what you did?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''yourmistakewayofcorrected'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''Tell me about the last time you made a mistake and how you corrected it?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''importantthingyoulearnedinjob'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''What is the most important thing you learned at previous or in your current job?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''previouspositionspreparedyou'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''How have your previous positions prepared you for this one?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''gradeyourabilitytocommunicate'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''How would you grade your ability to communicate with Upper level management, Customers, and/or peers?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    }]
}]', 2, true, '2018-04-25 07:32:52.952296', 1, NULL, 2);
INSERT INTO form_template (form_id, data, version_id, is_default, created_datetime, created_user_id, summary_fields, sort_order_id) VALUES (28, '[{
    settings: {
        hideActionButtons: [
            ''print'', ''mail''
        ]
    },fields: [{
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''name'',
                type: ''input'',
                className: ''col-lg-6'',
                templateOptions: {
                    label: ''Your Name'',
                    required: true
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''aboutprogenics'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''What do you know about Progenics'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''idealjob'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''Describe your ideal job'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''aboutthisposition'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''What interests you most about this position?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''motivatesyourbestwork'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''What motivates you to do your best work?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''mostfrustratingwork'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''What do you find most frustrating at work?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''projectyoureallyexcited'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''Tell me about a project that got you really excited?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''conditionyouworkbest'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''Under what condition do you work best?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''aboutyourlastposition'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''Tell me about your last position and what you did?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''yourmistakewayofcorrected'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''Tell me about the last time you made a mistake and how you corrected it?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''importantthingyoulearnedinjob'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''What is the most important thing you learned at previous or in your current job?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''previouspositionspreparedyou'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''How have your previous positions prepared you for this one?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    },
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''gradeyourabilitytocommunicate'',
                type: ''textarea'',
                className: ''col-lg-12'',
                templateOptions: {
                    label: ''How would you grade your ability to communicate with Upper level management, Customers, and/or peers?'',
                    required: false,
                    rows: 5
                }
            }
        ]
    }]
}]', 2, true, '2018-04-25 07:32:52.952296', 1, NULL, 2);
INSERT INTO form_template (form_id, data, version_id, is_default, created_datetime, created_user_id, summary_fields, sort_order_id) VALUES (9, '[{
   settings: {
        hideActionButtons: [
            ''preview'', ''completed'', ''edit'', ''save''
        ],
        mode:''nonedit''
    },
    fields: [
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''0'',
                type: ''checklist'',
                templateOptions: {
                    label: ''Before Joining'',
                    options: [
                        ''Identify and Orient buddy'',
                        ''Announcement to department/team'',
                        ''Welcome Call'',
                        ''Create schedule for first week'',
                        ''Finalise roles & responsibilities'',
                        ''Discuss role, goals and projects with reporting manager''
                    ]
                }
            },
            {
                key: ''1'',
                type: ''checklist'',
                templateOptions: {
                    label: ''First Day'',
                    options: [
                        ''Welcome meeting'',
                        ''Introduction to buddy, department and team'',
                        ''Team Lunch'',
                        ''Orient to role, responsibilities, expectations & Organisation''
                    ]
                }
            },
            {
                key: ''2'',
                type: ''checklist'',
                templateOptions: {
                    label: ''First Day'',
                    options: [
                        ''Welcome meeting'',
                        ''Introduction to buddy, department and team'',
                        ''Team Lunch'',
                        ''Orient to role, responsibilities, expectations & Organisation''
                    ]
                }
            },
            {
                key: ''3'',
                type: ''checklist'',
                templateOptions: {
                    label: ''First Week'',
                    options: [
                        ''Identify learning needs'',
                        ''Department overview & touch points'',
                        ''Add to check in meetings & weekly catch up'',
                        ''Determine & complete 30-60-90 day plan''
                    ]
                }
            },
            {
                key: ''4'',
                type: ''checklist'',
                templateOptions: {
                    label: ''30 Days – Understand'',
                    options: [
                        ''Ensure new joiner is gets to know the Organisation’s culture'',
                        ''Capability to understand the Competencies and training requirements'',
                        ''Assign project and monitor'',
                        ''Build a career development plan with specific goals, metric and KPI’s''
                    ]
                }
            },
            {
                key: ''5'',
                type: ''checklist'',
                templateOptions: {
                    label: ''60 Days – Assess'',
                    options: [
                        ''Identify issues or pain points with the roles-develop plans to address and fix the issues'',
                        ''Get feedback from immediate reporting manager'',
                        ''Competency analysis and training requirement proposal'',
                        ''Extended team collaboration''
                    ]
                }
            },
            {
                key: ''6'',
                type: ''checklist'',
                templateOptions: {
                    label: ''90 Days – Optimise'',
                    options: [
                        ''Start to work on independent project'',
                        ''Ensure accountability'',
                        ''Consult with immediate manager for feedback about goals/metrics/KPIs going forward'',
                        ''Review development plan''
                    ]
                }
            }
        ]
    }
 ]
}]', 2, true, '2018-04-24 10:32:52.952296', 1, NULL, 4);
INSERT INTO form_template (form_id, data, version_id, is_default, created_datetime, created_user_id, summary_fields, sort_order_id) VALUES (8, '[{
    settings: {
        hideActionButtons: [
            ''print'', ''mail''
        ]
    },
    fields: [
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''email'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Email address'',
                        type: ''email'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''name'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Your Name'',
                        required: true
                    }
                },
                {
                    key: ''position'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Position being hired for'',
                        required: true
                    }
                },
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''dateofinterview'',
                    type: ''input'',
                    className: ''col-lg-4'',
                    templateOptions: {
                        label: ''Date of interview'',
                        type: ''date'',
                        required: true
                    }
                },
                {
                    key: ''candidatename'',
                    type: ''input'',
                    className: ''col-lg-8'',
                    templateOptions: {
                        label: ''Name of the candidate'',
                        required: true
                    }
                },
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''location'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Candidate Location'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            key: ''inverviewassessmentheader'',
            type: ''section-header'',
            templateOptions: {
                label: ''Interview Assessment''
            }
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''summary'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Summary of the interview'',
                        description: ''How did the interview go? Level of interest/enthusiasm from the candidate. What did/did not go well?'',
                        rows: 5
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''technicalassessment'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Technical Assessment'',
                        description: ''How qualified and experienced is the candidate technically for this role? What areas would you like to highlight in terms of her/his technical skills? Where did you observe are the gaps?'',
                        rows: 5
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''competencyrating'',
                    type: ''rating'',
                    templateOptions: {
                        label: ''How would you assess the candidate on the following Competencies? '',
                        description: ''Based on your discussion how would you evaluate the candidate\''s competencies. You may want to use the Behavioural Event Interview (BEI) Guide having the list of questions.''
                    },
                    defaultValue: [{}],
                    fieldArray: {
                        fieldGroup: [
                            {
                                key: ''drivesvision'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Drives Vision and Purpose'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''comminucation'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Communicates Effectively'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''strategic'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Strategic Mindset'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''balancestakeholder'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Balances Stakeholders'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''businessinsight'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Business Insight'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''plansandaligns'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Plans and Aligns'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''optimizesworkprocess'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Optimizes Work Processes'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''drivesengagement'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Drives Engagement'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''decisionquality'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Decision Quality'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''techsavvy'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Tech Savvy'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''collaborates'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Collaborates'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''niblelearning'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Nimble Learning'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''cultivatesinnovation'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Cultivates Innovation'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''situationaladaptability'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Situational Adaptability'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            }
                        ]
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''highlight'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Based on the above Competencies, is there anything you would like to highlight ?'',
                        description: ''Aspects around what was his/her strengths and essential for the role. Anything that is critical for the role but the candidate did/did not possess ?'',
                        rows: 5
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            key: ''finalrecommendation'',
            type: ''section-header'',
            templateOptions: {
                label: ''Final Recommentation''
            }
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''decision'',
                    type: ''radio'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''What is your decision regarding the candidate?'',
                        options: [
                            { key: ''no'', value: ''Not to proceed'' },
                            { key: ''yes'', value: ''Proceed with next round'' }
                        ]
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''rationale'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Your rationale behind the decision'',
                        rows: 5
                    }
                }
            ]
        }
    ]
}]', 2, true, '2018-04-25 07:32:52.952296', 1, NULL, 3);
INSERT INTO form_template (form_id, data, version_id, is_default, created_datetime, created_user_id, summary_fields, sort_order_id) VALUES (10, '[{
    settings: {
        hideActionButtons: [
            ''print'', ''mail''
        ]
    },fields: [
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''name'',
                    type: ''input'',
                    className: ''col-lg-6 form-title-ui'',
                    templateOptions: {
                        label: ''Name'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [{
                key: ''thirtysixtyninty'',
                type: ''30-60-90'',
                defaultValue: [{}],
                fieldArray: {
                    fieldGroup: [
                        {
                            key: ''understandingcompany'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Understanding Company''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''understandsystemtools'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Understanding various systems & tools''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''meetingleaders'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Meetings with key leaders''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''meetingteam'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Meeting with team & other members''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''goalsetting'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Goal setting''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''goalsetting'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Goal setting''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''specialproject'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Special Project''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''improvement'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                // tslint:disable-next-line:max-line-length
                                label: ''Continuous improvement : 30 (identify 1-2 areas) 60 - propose improvements 90 - carry out improvements''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''colleguefeedback'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Colleague Feedback''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''managerfeedback'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Manager Feedback''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        }
                    ]
                }
            }]
        }
    ]
}]', 2, true, '2018-04-25 07:32:52.952296', 1, NULL, 5);
INSERT INTO form_template (form_id, data, version_id, is_default, created_datetime, created_user_id, summary_fields, sort_order_id) VALUES (12, '
[{  settings: {
        hideActionButtons: [ ]
    },
    fields:
    [
        {
            fieldGroupClassName: "row",
            fieldGroup: [
                {
                    key: "title",
                    type: "input",
                    className: "col-lg-6 form-title-ui",
                    templateOptions: {
                        label: "Title",
                        required: true
                    }
                }
            ]
        },
        {
            key: "sml",
            fieldGroup: [
                {
                    type: "sml",
                    fieldGroup: [
                        {
                            key: "shorttarget",
                            type: "sml-target-header",
                            templateOptions: {
                                label: "Short",
                                placeholder: "(Your Target)",
                                className:"sml-ui-short",
                                required: true
                            }
                        },
                        {
                            key: "mediumtarget",
                            type: "sml-target-header",
                            templateOptions: {
                                label: "Medium",
                                placeholder: "(Your Target)",
                                className: "sml-ui-medium",
                                required: true
                            }
                        },
                        {
                            key: "longtarget",
                            type: "sml-target-header",
                            templateOptions: {
                                label: "Long",
                                placeholder: "(Your Target)",
                                required: true,
                                className: "sml-ui-long",
                                isOngoing: true
                            }
                        },
                        {
                            key: "tasks",
                            type: "sml-target-row",
                            templateOptions: {
                                placeholder: "Task Details...",
                                targetCellProperties: {
                                    short: {
                                        key: "shorttarget",
                                        label: "Short",
                                        highlightClassname: "sml-ui-td-active-short"
                                    },
                                    medium: {
                                        key: "mediumtarget",
                                        label: "Medium",
                                        highlightClassname: "sml-ui-td-active-medium"
                                    },
                                    longFixed: {
                                        key: "longtarget",
                                        label: "Long",
                                        highlightClassname: "sml-ui-td-active-long-1"
                                    },
                                    longOngoing: {
                                        key: "longongoing",
                                        label: "Ongoing",
                                        highlightClassname: "sml-ui-td-active-long-2"
                                    },
                                }
                            }
                        }
                    ]
                }
            ]
        }
    ]
}]', 1, true, '2018-03-30 10:04:50.265662', 1, '[{"field" : "title", "title" : "Title" }]', 6);
INSERT INTO form_template (form_id, data, version_id, is_default, created_datetime, created_user_id, summary_fields, sort_order_id) VALUES (22, '[{
    settings: {
        hideActionButtons: [
            ''print'', ''mail''
        ]
    },
    fields: [
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''email'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Email address'',
                        type: ''email'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''name'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Your Name'',
                        required: true
                    }
                },
                {
                    key: ''position'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Position being hired for'',
                        required: true
                    }
                },
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''dateofinterview'',
                    type: ''input'',
                    className: ''col-lg-4'',
                    templateOptions: {
                        label: ''Date of interview'',
                        type: ''date'',
                        required: true
                    }
                },
                {
                    key: ''candidatename'',
                    type: ''input'',
                    className: ''col-lg-8'',
                    templateOptions: {
                        label: ''Name of the candidate'',
                        required: true
                    }
                },
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''location'',
                    type: ''input'',
                    className: ''col-lg-6'',
                    templateOptions: {
                        label: ''Candidate Location'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            key: ''inverviewassessmentheader'',
            type: ''section-header'',
            templateOptions: {
                label: ''Interview Assessment''
            }
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''summary'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Summary of the interview'',
                        description: ''How did the interview go? Level of interest/enthusiasm from the candidate. What did/did not go well?'',
                        rows: 5
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''technicalassessment'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Technical Assessment'',
                        description: ''How qualified and experienced is the candidate technically for this role? What areas would you like to highlight in terms of her/his technical skills? Where did you observe are the gaps?'',
                        rows: 5
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''competencyrating'',
                    type: ''rating'',
                    templateOptions: {
                        label: ''How would you assess the candidate on the following Competencies? '',
                        description: ''Based on your discussion how would you evaluate the candidate\''s competencies. You may want to use the Behavioural Event Interview (BEI) Guide having the list of questions.''
                    },
                    defaultValue: [{}],
                    fieldArray: {
                        fieldGroup: [
                            {
                                key: ''drivesvision'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Drives Vision and Purpose'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''comminucation'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Communicates Effectively'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''strategic'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Strategic Mindset'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''balancestakeholder'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Balances Stakeholders'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''businessinsight'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Business Insight'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''plansandaligns'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Plans and Aligns'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''optimizesworkprocess'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Optimizes Work Processes'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''drivesengagement'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Drives Engagement'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''decisionquality'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Decision Quality'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''techsavvy'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Tech Savvy'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''collaborates'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Collaborates'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''niblelearning'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Nimble Learning'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''cultivatesinnovation'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Cultivates Innovation'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            },
                            {
                                key: ''situationaladaptability'',
                                type: ''rating-radio-row'',
                                templateOptions: {
                                    label: ''Situational Adaptability'',
                                    options: [
                                        { ''key'': ''excellent'', ''value'': ''Excellent'' },
                                        { ''key'': ''good'', ''value'': ''Good'' },
                                        { ''key'': ''fair'', ''value'': ''Moderate/Fair'' },
                                        { ''key'': ''poor'', ''value'': ''Poor'' },
                                        { ''key'': ''noaccess'', ''value'': ''Did not access'' },
                                        { ''key'': ''na'', ''value'': ''Not essential for the role'' }
                                    ]
                                }
                            }
                        ]
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''highlight'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Based on the above Competencies, is there anything you would like to highlight ?'',
                        description: ''Aspects around what was his/her strengths and essential for the role. Anything that is critical for the role but the candidate did/did not possess ?'',
                        rows: 5
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            key: ''finalrecommendation'',
            type: ''section-header'',
            templateOptions: {
                label: ''Final Recommentation''
            }
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''decision'',
                    type: ''radio'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''What is your decision regarding the candidate?'',
                        options: [
                            { key: ''no'', value: ''Not to proceed'' },
                            { key: ''yes'', value: ''Proceed with next round'' }
                        ]
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''rationale'',
                    type: ''textarea'',
                    className: ''col-lg-12'',
                    templateOptions: {
                        label: ''Your rationale behind the decision'',
                        rows: 5
                    }
                }
            ]
        }
    ]
}]', 2, true, '2018-04-25 07:32:52.952296', 1, NULL, 3);
INSERT INTO form_template (form_id, data, version_id, is_default, created_datetime, created_user_id, summary_fields, sort_order_id) VALUES (23, '[{
    settings: {
        hideActionButtons: [
            ''preview'', ''completed'', ''edit'', ''save''
        ],
        mode:''nonedit''
    },
    fields: [
    {
        fieldGroupClassName: ''row'',
        fieldGroup: [
            {
                key: ''0'',
                type: ''checklist'',
                templateOptions: {
                    label: ''Before Joining'',
                    options: [
                        ''Identify and Orient buddy'',
                        ''Announcement to department/team'',
                        ''Welcome Call'',
                        ''Create schedule for first week'',
                        ''Finalise roles & responsibilities'',
                        ''Discuss role, goals and projects with reporting manager''
                    ]
                }
            },
            {
                key: ''1'',
                type: ''checklist'',
                templateOptions: {
                    label: ''First Day'',
                    options: [
                        ''Welcome meeting'',
                        ''Introduction to buddy, department and team'',
                        ''Team Lunch'',
                        ''Orient to role, responsibilities, expectations & Organisation''
                    ]
                }
            },
            {
                key: ''2'',
                type: ''checklist'',
                templateOptions: {
                    label: ''First Day'',
                    options: [
                        ''Welcome meeting'',
                        ''Introduction to buddy, department and team'',
                        ''Team Lunch'',
                        ''Orient to role, responsibilities, expectations & Organisation''
                    ]
                }
            },
            {
                key: ''3'',
                type: ''checklist'',
                templateOptions: {
                    label: ''First Week'',
                    options: [
                        ''Identify learning needs'',
                        ''Department overview & touch points'',
                        ''Add to check in meetings & weekly catch up'',
                        ''Determine & complete 30-60-90 day plan''
                    ]
                }
            },
            {
                key: ''4'',
                type: ''checklist'',
                templateOptions: {
                    label: ''30 Days – Understand'',
                    options: [
                        ''Ensure new joiner is gets to know the Organisation’s culture'',
                        ''Capability to understand the Competencies and training requirements'',
                        ''Assign project and monitor'',
                        ''Build a career development plan with specific goals, metric and KPI’s''
                    ]
                }
            },
            {
                key: ''5'',
                type: ''checklist'',
                templateOptions: {
                    label: ''60 Days – Assess'',
                    options: [
                        ''Identify issues or pain points with the roles-develop plans to address and fix the issues'',
                        ''Get feedback from immediate reporting manager'',
                        ''Competency analysis and training requirement proposal'',
                        ''Extended team collaboration''
                    ]
                }
            },
            {
                key: ''6'',
                type: ''checklist'',
                templateOptions: {
                    label: ''90 Days – Optimise'',
                    options: [
                        ''Start to work on independent project'',
                        ''Ensure accountability'',
                        ''Consult with immediate manager for feedback about goals/metrics/KPIs going forward'',
                        ''Review development plan''
                    ]
                }
            }
        ]
    }
 ]
}]', 2, true, '2018-04-24 10:32:52.952296', 1, NULL, 4);
INSERT INTO form_template (form_id, data, version_id, is_default, created_datetime, created_user_id, summary_fields, sort_order_id) VALUES (24, '[{
   settings: {
        hideActionButtons: [
            ''print'', ''mail''
        ]
    },fields: [
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [
                {
                    key: ''name'',
                    type: ''input'',
                    className: ''col-lg-6 form-title-ui'',
                    templateOptions: {
                        label: ''Name'',
                        required: true
                    }
                }
            ]
        },
        {
            fieldGroupClassName: ''row'',
            fieldGroup: [{
                key: ''thirtysixtyninty'',
                type: ''30-60-90'',
                defaultValue: [{}],
                fieldArray: {
                    fieldGroup: [
                        {
                            key: ''understandingcompany'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Understanding Company''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''understandsystemtools'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Understanding various systems & tools''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''meetingleaders'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Meetings with key leaders''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''meetingteam'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Meeting with team & other members''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''goalsetting'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Goal setting''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''goalsetting'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Goal setting''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''specialproject'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Special Project''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''improvement'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                // tslint:disable-next-line:max-line-length
                                label: ''Continuous improvement : 30 (identify 1-2 areas) 60 - propose improvements 90 - carry out improvements''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''colleguefeedback'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Colleague Feedback''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        },
                        {
                            key: ''managerfeedback'',
                            type: ''30-60-90-row'',
                            templateOptions: {
                                label: ''Manager Feedback''
                            },
                            fieldGroup: [{ key: ''thirty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''sixty'', templateOptions: { placeholder: ''Type here'' } },
                            { key: ''ninty'', templateOptions: { placeholder: ''Type here'' } }]
                        }
                    ]
                }
            }]
        }
    ]
}]', 2, true, '2018-04-25 07:32:52.952296', 1, NULL, 5);
INSERT INTO form_template (form_id, data, version_id, is_default, created_datetime, created_user_id, summary_fields, sort_order_id) VALUES (19, '
[{  settings: {
        hideActionButtons: [ ]
    },
    fields:
    [
        {
            fieldGroupClassName: "row",
            fieldGroup: [
                {
                    key: "title",
                    type: "input",
                    className: "col-lg-6 form-title-ui",
                    templateOptions: {
                        label: "Title",
                        required: true
                    }
                }
            ]
        },
        {
            key: "sml",
            fieldGroup: [
                {
                    type: "sml",
                    fieldGroup: [
                        {
                            key: "shorttarget",
                            type: "sml-target-header",
                            templateOptions: {
                                label: "Short",
                                placeholder: "(Your Target)",
                                className:"sml-ui-short",
                                required: true
                            }
                        },
                        {
                            key: "mediumtarget",
                            type: "sml-target-header",
                            templateOptions: {
                                label: "Medium",
                                placeholder: "(Your Target)",
                                className: "sml-ui-medium",
                                required: true
                            }
                        },
                        {
                            key: "longtarget",
                            type: "sml-target-header",
                            templateOptions: {
                                label: "Long",
                                placeholder: "(Your Target)",
                                required: true,
                                className: "sml-ui-long",
                                isOngoing: true
                            }
                        },
                        {
                            key: "tasks",
                            type: "sml-target-row",
                            templateOptions: {
                                placeholder: "Task Details...",
                                targetCellProperties: {
                                    short: {
                                        key: "shorttarget",
                                        label: "Short",
                                        highlightClassname: "sml-ui-td-active-short"
                                    },
                                    medium: {
                                        key: "mediumtarget",
                                        label: "Medium",
                                        highlightClassname: "sml-ui-td-active-medium"
                                    },
                                    longFixed: {
                                        key: "longtarget",
                                        label: "Long",
                                        highlightClassname: "sml-ui-td-active-long-1"
                                    },
                                    longOngoing: {
                                        key: "longongoing",
                                        label: "Ongoing",
                                        highlightClassname: "sml-ui-td-active-long-2"
                                    },
                                }
                            }
                        }
                    ]
                }
            ]
        }
    ]
}]', 1, true, '2018-03-30 10:04:50.265662', 1, '[{"field" : "title", "title" : "Title" }]', 6);


INSERT INTO resource (name, title, category_id, resource_type, description, id, property, sort_order_id, is_active) VALUES ('checklist', 'CheckList Guide', 15, 'PDF', ' ', 13, '{ "path": "/assets/files/Checklist.pdf" }', 1, true);
INSERT INTO resource (name, title, category_id, resource_type, description, id, property, sort_order_id, is_active) VALUES ('30-60-90', '30-60-90 Plan Guide', 15, 'PDF', ' ', 14, '{ "path": "/assets/files/30-60-90-Plan.pdf"}', 2, true);
INSERT INTO resource (name, title, category_id, resource_type, description, id, property, sort_order_id, is_active) VALUES ('sml', 'Planning (SML)', 22, 'PDF', ' ', 15, '{"path": "/assets/files/SML.pdf"}', 1, true);
INSERT INTO resource (name, title, category_id, resource_type, description, id, property, sort_order_id, is_active) VALUES ('bei-guide', 'BEI Guide', 17, 'PDF', ' ', 16, '{"path":"/assets/files/BEI_Hand_out.pdf"}', 1, true);
INSERT INTO resource (name, title, category_id, resource_type, description, id, property, sort_order_id, is_active) VALUES ('conducting-effective-interviews', 'Conducting Effective Interviews', 17, 'PDF', ' ', 17, '{"path":"/assets/files/Conducting_Effective_Interviews.pdf"}', 2, true);
INSERT INTO resource (name, title, category_id, resource_type, description, id, property, sort_order_id, is_active) VALUES ('checklist', 'CheckList Guide', 28, 'PDF', ' ', 18, '{ "path": "/assets/files/Checklist.pdf" }', 1, true);
INSERT INTO resource (name, title, category_id, resource_type, description, id, property, sort_order_id, is_active) VALUES ('30-60-90', '30-60-90 Plan Guide', 28, 'PDF', ' ', 19, '{ "path": "/assets/files/30-60-90-Plan.pdf"}', 2, true);
INSERT INTO resource (name, title, category_id, resource_type, description, id, property, sort_order_id, is_active) VALUES ('sml', 'Planning (SML)', 33, 'PDF', ' ', 20, '{"path": "/assets/files/SML.pdf"}', 1, true);
INSERT INTO resource (name, title, category_id, resource_type, description, id, property, sort_order_id, is_active) VALUES ('bei-guide', 'BEI Guide', 26, 'PDF', ' ', 21, '{"path":"/assets/files/BEI_Hand_out.pdf"}', 1, true);
INSERT INTO resource (name, title, category_id, resource_type, description, id, property, sort_order_id, is_active) VALUES ('conducting-effective-interviews', 'Conducting Effective Interviews', 26, 'PDF', ' ', 22, '{"path":"/assets/files/Conducting_Effective_Interviews.pdf"}', 2, true);


SELECT setval('user_user_id_seq', coalesce((select max(user_id) from "user"), 1), true); 
SELECT setval('section_id_seq', coalesce((select max(id) from section), 1), true); 
SELECT setval('category_id_seq', coalesce((select max(id) from category), 1), true); 
SELECT setval('resource_id_seq', coalesce((select max(id) from resource), 1), true); 
SELECT setval('form_id_seq1', coalesce((select max(id) from form), 1), true); 
SELECT setval('form_template_id_seq', coalesce((select max(id) from form_template), 1), true); 