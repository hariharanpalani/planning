DELETE from public.form_template WHERE form_id IN (1, 2, 3, 5, 6) and version_id = 2;

UPDATE public.form_template SET is_default = true WHERE id IN (1, 2, 3, 5, 6);