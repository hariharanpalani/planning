/* Replace with your SQL commands */

DROP FUNCTION public.search_user(user_search_criteria);


CREATE FUNCTION search_user(search_criteria user_search_criteria) RETURNS TABLE(user_id integer, full_name character varying, email character varying, is_admin boolean, tenant_id uuid)
    LANGUAGE plpgsql
    AS $$
	
Begin
		
	RETURN QUERY SELECT usr.user_id, usr.full_name, usr.email, usr.is_admin, usr.tenant_id FROM "user" usr
    WHERE (search_criteria.user_ids IS NULL OR usr.user_id = ANY(search_criteria.user_ids))
    AND (search_criteria.tenant_id IS NULL OR usr.tenant_id = search_criteria.tenant_id)
    AND (search_criteria.name IS NULL OR LOWER(usr.full_name) LIKE ('%' || LOWER(search_criteria.name) || '%'))
    AND (search_criteria.email IS NULL OR LOWER(usr.email) LIKE ('%' || LOWER(search_criteria.email) || '%'))
    AND (usr.is_active = true OR (search_criteria.include_inactive IS NOT NULL AND usr.is_active = NOT search_criteria.include_inactive));

END	

$$;

