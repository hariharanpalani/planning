CREATE TABLE public.organization
(
    description text COLLATE pg_catalog."default",
    full_name character varying(250) COLLATE pg_catalog."default" NOT NULL,
    tenant_id uuid NOT NULL,
    unique_name character(20) COLLATE pg_catalog."default" NOT NULL,
    logo_path character varying(250) COLLATE pg_catalog."default",
    domain_name character varying(90) COLLATE pg_catalog."default",
    settings json,
    CONSTRAINT organization_pkey PRIMARY KEY (unique_name)
)
WITH (
    OIDS = FALSE
);

CREATE SEQUENCE user_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE TABLE public."user"
(
    user_id integer NOT NULL DEFAULT nextval('user_user_id_seq'::regclass),
    email character varying(250) COLLATE pg_catalog."default" NOT NULL,
    password_hash character varying(1000) COLLATE pg_catalog."default",
    salt uuid,
    created_ip character varying(50) COLLATE pg_catalog."default",
    created_datetime timestamp(6) without time zone,
    last_login_ip character varying(50) COLLATE pg_catalog."default",
    last_login_datetime timestamp(6) without time zone,
    login_ip character varying(50) COLLATE pg_catalog."default",
    disabled boolean,
    disabled_reason character varying(1000) COLLATE pg_catalog."default",
    disabled_internal_reason character varying(1000) COLLATE pg_catalog."default",
    login_try integer,
    locked boolean,
    locked_datetime timestamp with time zone,
    tenant_id uuid,
    is_admin boolean NOT NULL,
    login_datetime timestamp without time zone,
    full_name character varying(250) COLLATE pg_catalog."default",
    is_active boolean NOT NULL DEFAULT true,
    CONSTRAINT user_pkey PRIMARY KEY (email)
)
WITH (
    OIDS = FALSE
);

CREATE SEQUENCE section_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


CREATE TABLE public.section
(
    name character varying(250) COLLATE pg_catalog."default",
    logo_path character varying(250) COLLATE pg_catalog."default",
    title character varying(250) COLLATE pg_catalog."default",
    tenant_id uuid,
    id integer NOT NULL DEFAULT nextval('section_id_seq'::regclass),
    is_active boolean NOT NULL DEFAULT true,
    is_enabled boolean NOT NULL DEFAULT true,
    sort_order_id integer
)
WITH (
    OIDS = FALSE
);

CREATE SEQUENCE category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE TABLE public.category
(
    name character varying(250) COLLATE pg_catalog."default",
    title character varying(250) COLLATE pg_catalog."default",
    description character varying(1000) COLLATE pg_catalog."default",
    section_id integer,
    created_datetime timestamp without time zone,
    created_user_id integer,
    tenant_id uuid,
    is_active boolean,
    id integer NOT NULL DEFAULT nextval('category_id_seq'::regclass),
    is_enabled boolean NOT NULL DEFAULT true,
    sort_order_id integer,
    CONSTRAINT category_pkey PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
);


CREATE SEQUENCE resource_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


CREATE TABLE public.resource
(
    name character varying(250) COLLATE pg_catalog."default",
    title character varying(250) COLLATE pg_catalog."default",
    category_id integer,
    resource_type character varying(50) COLLATE pg_catalog."default",
    description character varying(250) COLLATE pg_catalog."default",
    id integer NOT NULL DEFAULT nextval('resource_id_seq'::regclass),
    property json,
    sort_order_id integer,
    is_active boolean NOT NULL DEFAULT true
)
WITH (
    OIDS = FALSE
);


CREATE SEQUENCE form_id_seq1
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE TABLE public.form
(
    name character varying(250) COLLATE pg_catalog."default",
    title character varying(250) COLLATE pg_catalog."default",
    description character varying(1000) COLLATE pg_catalog."default",
    created_datetime timestamp without time zone,
    created_user_id integer,
    form_type character varying(20) COLLATE pg_catalog."default",
    id integer NOT NULL DEFAULT nextval('form_id_seq1'::regclass),
    category_id integer,
    sort_order_id integer,
    is_active boolean NOT NULL DEFAULT true
)
WITH (
    OIDS = FALSE
);


CREATE SEQUENCE form_template_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


CREATE TABLE public.form_template
(
    id integer NOT NULL DEFAULT nextval('form_template_id_seq'::regclass),
    form_id integer NOT NULL,
    data text,
    version_id integer,
    is_default boolean DEFAULT false,
    created_datetime timestamp without time zone,
    created_user_id integer,
    summary_fields json,
    sort_order_id integer,
    CONSTRAINT form_template_pkey PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
);


CREATE SEQUENCE form_data_id_form_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


CREATE TABLE public.form_data
(
    form_template_id integer,
    data json,
    created_user_id integer,
    is_complete boolean,
    id integer NOT NULL DEFAULT nextval('form_data_id_form_seq'::regclass),
    last_updated_user_id integer,
    last_updated_datetime timestamp without time zone
)
WITH (
    OIDS = FALSE
);


CREATE SEQUENCE user_form_relation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


CREATE TABLE public.user_form_relation
(
    id integer NOT NULL DEFAULT nextval('user_form_relation_id_seq'::regclass),
    user_id integer NOT NULL,
    form_data_id integer NOT NULL,
    is_read_only boolean NOT NULL DEFAULT false,
    CONSTRAINT user_form_relation_pkey PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
);


CREATE SEQUENCE log_user_login_auto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


CREATE TABLE public.log_user_login
(
    email character varying(250) COLLATE pg_catalog."default",
    ip character varying(50) COLLATE pg_catalog."default",
    login_datetime timestamp with time zone,
    login_success boolean,
    auto_id integer NOT NULL DEFAULT nextval('log_user_login_auto_id_seq'::regclass)
)
WITH (
    OIDS = FALSE
);


