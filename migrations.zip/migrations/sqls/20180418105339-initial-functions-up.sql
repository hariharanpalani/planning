CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE form_search_criteria AS (
	form_id integer,
	owner_id integer,
	form_template_id integer,
	section_id integer,
	category_id integer,
	related_user_ids integer[],
	include_saved boolean,
	created_start_date timestamp without time zone,
	created_end_date timestamp without time zone,
	last_update_start_date timestamp without time zone,
	last_update_end_date timestamp without time zone
);

CREATE TYPE organization_search_criteria AS (
	tenant_id uuid,
	domain_name character varying
);

CREATE TYPE user_search_criteria AS (
	user_ids integer[],
	tenant_id uuid,
	name character varying,
	email character varying,
	include_inactive boolean
);

CREATE FUNCTION add_remove_form_users(_form_data_id integer, _user_ids integer[]) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE _user_id integer;
BEGIN

	DELETE FROM user_form_relation WHERE form_data_id = _form_data_id;
    
    IF FOUND THEN 
		FOREACH _user_id IN ARRAY _user_ids
        LOOP
            INSERT INTO user_form_relation (user_id, form_data_id) VALUES(_user_id, _form_data_id);
        END LOOP;
	ELSE
		RETURN 0; --FORM DATA NOT FOUND
    END IF;   
    
	RETURN 1;
    
END
$$;


CREATE FUNCTION create_user_login(email character varying, password character varying, tenant_id uuid, is_admin boolean, full_name character varying) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$

DECLARE salt UUID;
DECLARE user_id integer = 0;
DECLARE password_hash character varying(1000);
BEGIN

salt := gen_random_uuid();

password_hash := crypt(password, salt::character varying(20));

INSERT INTO public.user( email, password_hash, salt, created_ip, created_datetime,  
						tenant_id, is_admin, full_name)
	VALUES (email, password_hash , salt, '127.0.0.1', now()::timestamp, 
			tenant_id, is_admin, full_name);

user_id := CURRVAL('user_user_id_seq');
			
RETURN user_id;
END

$$;



CREATE OR REPLACE FUNCTION public.get_form_data(
	_form_data_id integer)
    RETURNS TABLE(
    section_id integer,
    form_template_id integer,
    form_title character varying,
    form_desc character varying,
    tenant_id uuid,
    form_template text,
    form_data json,
    form_type character varying,
    owner_user_id integer,
    is_complete boolean,
    form_last_updated character varying
    ) 
    LANGUAGE 'plpgsql'

    COST 100
    VOLATILE 
    ROWS 1000
AS $BODY$

BEGIN
	DROP TABLE IF EXISTS tmpl_form_data;
	
	CREATE TEMPORARY TABLE tmpl_form_data
	AS
	SELECT * FROM form_data WHERE id = _form_data_id;
	
	RETURN QUERY SELECT sec.id, ft.id, f.title, f.description, sec.tenant_id, ft.data, fd.data, f.form_type, fd.created_user_id, fd.is_complete, fd.last_updated_datetime :: character varying
	from tmpl_form_data fd
	inner join form_template ft on ft.id = fd.form_template_id
	inner join form f on f.id = ft.form_id
	inner join category cat on cat.id = f.category_id
	inner join section sec on sec.id = cat.section_id;

END;

$BODY$;


CREATE OR REPLACE FUNCTION public.get_form_template(
	_form_template_id integer)
    RETURNS TABLE(
				template_id integer,
				section_id integer,
				form_name character varying,
				tenant_id uuid,
				title character varying,
				description character varying,
				form_type character varying, 
				fields text
	) 
    LANGUAGE 'sql'

    COST 100
    VOLATILE 
    ROWS 1000
AS $BODY$


select FT.id, cat.section_id, F.name,cat.tenant_id, F.title,F.description, F.form_type, FT.data as fields 
from form F 
join form_template FT on (F.id = FT.form_id) 
join category cat on (cat.id = f.category_id)
where FT.id = _form_template_id and F.is_active = true


$BODY$;


CREATE FUNCTION get_form_users(_form_data_id integer) RETURNS TABLE(user_id integer, full_name character varying, email character varying, owner_user_id integer)
    LANGUAGE sql
    AS $$
	
	SELECT U.user_id, U.full_name, U.email, FD.created_user_id FROM form_data FD
    INNER JOIN user_form_relation UF ON UF.form_data_id = FD.id
    INNER JOIN "user" U ON U.user_id = UF.user_id
    WHERE FD.id = _form_data_id	
	
$$;



CREATE FUNCTION get_saved_count(_user_id integer, _section_id integer) RETURNS bigint
    LANGUAGE sql
    AS $$

select count(1) 
FROM form_data FD 
join form_template FT on ( FD.form_template_id = FT.id ) 
Join form F on (F.id = FT.form_id  ) 
join category CAT on (CAT.id = F.category_id)
join "section" S on (S.id = CAT.section_id and S.tenant_id = CAT.tenant_id )
join user_form_relation UF on (UF.form_data_id = FD.id and UF.user_id = _user_id)
where S.id = _section_id AND UF.user_id = _user_id AND S.tenant_id = (select  U.tenant_id from "user" U where U.user_id = _user_id) 
and FD.is_complete = false and S.id = _section_id 

$$;



CREATE FUNCTION get_section_detail(_section_id integer) RETURNS TABLE(id integer, title character varying, tenant_id uuid, logo_path character varying, form_items json, res_items json)
    LANGUAGE plpgsql
    AS $$

DECLARE form_items json;
DECLARE res_items json;
DECLARE categories json;
BEGIN
	
	--form items
	select json_agg(fi.items) into form_items from 
	(select  json_build_object('name', cat.title, 'items', 
			json_agg(
			json_build_object(
								'id', tmpl.id, 
								'name', frm.name, 
								'title', frm.title,
								'description', frm.description, 
								'type', frm.form_type
			) order by tmpl.sort_order_id
			)
			) as items 
	from section s
	inner join category cat on cat.section_id = s.id and cat.is_active = true
	left outer join form frm on frm.category_id = cat.id and  frm.is_active = true
	left outer join form_template tmpl on tmpl.form_id = frm.id and tmpl.is_default = true
	where s.id = _section_id and s.is_active = true and cat.name = 'forms'
	group by cat.title) fi;

	select json_agg(r.items) into res_items from 
	(select json_build_object('name', cat.title, 'items', 
			json_agg(
			json_build_object(
								'id', res.id, 
								'name', res.name, 
								'title', res.title,
								'description', res.description,
								'type', res.resource_type,
								'property', res.property
			) order by res.sort_order_id
			)
			) as items
	from category cat
	left outer join resource res on  res.category_id = cat.id and res.is_active = true	
	inner join section s on s.id = cat.section_id and s.is_active = true
	where s.id = _section_id and cat.is_active = true and cat.name != 'forms'	
	group by cat.title, cat.sort_order_id Order by cat.sort_order_id) r;

		
	RETURN QUERY select s.id , s.title,s.tenant_id, s.logo_path, form_items , res_items from "section" s where s.id = _section_id;
END 

$$;



CREATE FUNCTION get_submitted_count(_user_id integer, _section_id integer) RETURNS bigint
    LANGUAGE sql
    AS $$

select count(1) 
FROM form_data FD 
join form_template FT on ( FD.form_template_id = FT.id ) 
Join form F on (F.id = FT.form_id  ) 
join category CAT on (CAT.id = F.category_id)
join "section" S on (S.id = CAT.section_id and S.tenant_id = CAT.tenant_id )
join user_form_relation UF on (UF.form_data_id = FD.id and UF.user_id = _user_id)
where S.id = _section_id AND UF.user_id = _user_id AND S.tenant_id = (select  U.tenant_id from "user" U where U.user_id = _user_id) 
and FD.is_complete = true and S.id = _section_id 

$$;


CREATE FUNCTION get_user_info(_user_id integer) RETURNS "user"
    LANGUAGE sql
    AS $$

select * from "user" where user_id = _user_id

$$;


CREATE FUNCTION get_user_sections(_user_id integer)
	RETURNS TABLE(id integer, title character, image character, items character varying[], saved bigint, submitted bigint, is_enabled boolean) 
    LANGUAGE sql
    AS $$


select 
		S.id, S.title, 
		S.logo_path, 
			array(
					(select f.title FROM form f 
						inner join category cat on cat.id = f.category_id 
				  		where 	cat.section_id = S.id 
				  		and 		cat.is_active = true 
				  		and 		f.is_active = true 
				  		order by 	f.sort_order_id
					)
				  UNION ALL 
					select distinct(title) from 
				  	(select cat.title from category cat 
						left outer join resource res on res.category_id = cat.id and res.is_active = true 
			      		where 	cat.section_id = s.id 
						and 	cat.is_active = true
						and cat.name != 'forms'
						order by cat.sort_order_id) AS cat
						) AS 
		items,
 				get_saved_count(_user_id, S.id) as 
		savedCount,
 				get_submitted_count(_user_id, S.id) as 
		submittedCount,
		S.is_enabled AS is_enabled
from 
	"section" S 
where 
	S.tenant_id = (select  U.tenant_id from "user" U where U.user_id = _user_id) 
	and S.is_active = true 
	ORDER BY S.sort_order_id

$$;



CREATE OR REPLACE FUNCTION public.search_form(
	search_criteria form_search_criteria)
    RETURNS TABLE(
        form_id integer,
        form_data json,
        form_template_id integer,
        form_template text,
        summary_fields json,
        form_title character varying,
        is_complete boolean,
        form_last_updated timestamp without time zone
        ) 
    LANGUAGE 'plpgsql'

    COST 100
    VOLATILE 
    ROWS 1000
AS $BODY$


Begin
	
	RETURN QUERY Select FD.id, FD."data", FD.form_template_id, FT.data, FT.summary_fields, F.title, FD.is_complete, FD.last_updated_datetime   
	FROM form_data FD 
	INNER JOIN form_template FT ON FT.id = FD.form_template_id
	INNER JOIN form F ON F.id = FT.form_id
	INNER JOIN category CAT ON CAT.id = F.category_id
	INNER JOIN section SEC on SEC.id = CAT.section_id
	WHERE (search_criteria.form_id IS NULL OR FD.id = search_criteria.form_id)
	AND (search_criteria.owner_id IS NULL OR FD.created_user_id = search_criteria.owner_id)
	AND (search_criteria.template_id IS NULL OR FT.id = search_criteria.template_id)
	AND (search_criteria.section_id IS NULL OR SEC.id = search_criteria.section_id)
	AND (search_criteria.last_update_start_date IS NULL OR FD.last_updated_datetime >= search_criteria.last_update_start_date :: date)
	AND (search_criteria.last_update_end_date IS NULL OR FD.last_updated_datetime < (search_criteria.last_update_end_date :: date + '1 day'::interval))
	AND (FD.is_complete = true OR (search_criteria.include_saved IS NOT NULL AND FD.is_complete = NOT search_criteria.include_saved))
	ORDER BY FD.last_updated_datetime desc;
	
	
End


$BODY$;


CREATE FUNCTION search_user(search_criteria user_search_criteria) RETURNS TABLE(user_id integer, full_name character varying, email character varying, is_admin boolean, tenant_id uuid)
    LANGUAGE plpgsql
    AS $$
	
Begin
		
	RETURN QUERY SELECT usr.user_id, usr.full_name, usr.email, usr.is_admin, usr.tenant_id FROM "user" usr
    WHERE (search_criteria.user_ids IS NULL OR usr.user_id = ANY(search_criteria.user_ids))
    AND (search_criteria.tenant_id IS NULL OR usr.tenant_id = search_criteria.tenant_id)
    AND (search_criteria.name IS NULL OR LOWER(usr.full_name) LIKE ('%' || LOWER(search_criteria.name) || '%'))
    AND (search_criteria.email IS NULL OR LOWER(usr.email) LIKE ('%' || LOWER(search_criteria.email) || '%'))
    AND (usr.is_active = true OR (search_criteria.include_inactive IS NOT NULL AND usr.is_active = NOT search_criteria.include_inactive));

END	

$$;



CREATE FUNCTION update_form(_form_id integer, _form_data json, _is_complete boolean, _user_id integer, _last_updated_datetime timestamp without time zone) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN

UPDATE form_data SET "data" = _form_data, 
	 				 last_updated_user_id = _user_id, 
					 last_updated_datetime = CURRENT_TIMESTAMP at time zone 'utc',
					 is_complete = _is_complete
WHERE id = _form_id AND last_updated_datetime = _last_updated_datetime;

IF FOUND THEN 
	RETURN 1;
ELSE
	IF EXISTS (SELECT 1 FROM form_data WHERE id = _form_id) THEN
  		RETURN -1; -- Confict as the form got updated after read
	ELSE
		RETURN 0; -- Form not found 
	END IF;
END IF;

END

$$;



CREATE FUNCTION validate_user_login(_email character varying, _password character varying, _login_ip character varying) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$

DECLARE success BOOLEAN;
DECLARE message CHARACTER VARYING(500);  
DECLARE password_hash CHARACTER VARYING(1000);
DECLARE is_user_exist BOOLEAN = false;
DECLARE password_hash_col CHARACTER VARYING(1000); 
DECLARE salt_col UUID;
DECLARE salt_col_var CHARACTER VARYING(100);
DECLARE is_disabled_col BOOLEAN = false;
DECLARE disabled_reason_col CHARACTER VARYING(1000);
DECLARE is_locked_col BOOLEAN;
DECLARE is_admin_col BOOLEAN;
DECLARE last_login_ip_col CHARACTER VARYING(50);
DECLARE last_login_datetime_col TIMESTAMP WITHOUT TIME ZONE;
DECLARE login_try_col INTEGER = 1;
DECLARE locked_datetime_col TIMESTAMP WITHOUT TIME ZONE;
DECLARE org_tenant_id_col UUID;
DECLARE org_full_name_col CHARACTER VARYING(250);
DECLARE org_logo_path_col CHARACTER VARYING(250);
DECLARE user_exist BOOLEAN;
DECLARE user_locked BOOLEAN;
DECLARE last_try BOOLEAN;
DECLARE is_locked_now BOOLEAN = false;
DECLARE return_data JSON;
DECLARE user_id_col INTEGER = 0;
BEGIN
success := false;
message := 'unable to validate user';

SELECT  u.password_hash, u.salt, u.disabled, u.disabled_reason, u.locked, 
		u.locked_datetime, u.tenant_id, u.is_admin, u.login_try, u.login_datetime, u.login_ip, u.User_Id INTO 
		password_hash_col, salt_col, is_disabled_col, message, is_locked_col, 
		locked_datetime_col,org_tenant_id_col, is_admin_col, login_try_col, last_login_datetime_col, last_login_ip_col, user_id_col
FROM "user" u WHERE u.email = _email;

IF (COALESCE(user_id_col,0) = 0) THEN
	message := 'User does not exist';
ELSEIF (COALESCE(is_disabled_col,false) = true) THEN
	message := 'User is disabled; Reason:' + message;
ELSEIF (is_locked_col = true AND locked_datetime_col > now()::timestamp ) THEN
	message := 'User is locked;';
ELSE
	salt_col_var := salt_col::"varchar";
	password_hash := crypt(_password, salt_col_var);
	IF (password_hash = password_hash_col) THEN
	
		UPDATE "user" SET last_login_ip = last_login_ip_col, last_login_datetime = last_login_datetime_col,
			login_datetime = now()::timestamp, login_ip = _login_ip,
			login_try = 0, locked = false, locked_datetime = NULL
		WHERE 
			email = _email;
		
		INSERT INTO log_user_login (email, ip, login_datetime, login_success )
		VALUES (_email, _login_ip, now()::timestamp, true);
		
		success := true;
		message := '';
	ELSE
		login_try_col := COALESCE(login_try_col,0) + 1;
		message := 'Password is not valid';
		
		IF (login_try_col >= 4) THEN
			is_locked_col :=  true;
			is_locked_now := true;
			locked_datetime_col := now()::timestamp + interval '24h';
		END IF;
		
		UPDATE "user" SET 
			login_try = login_try_col, 
			"locked" = CASE WHEN login_try_col >= 4 THEN true ELSE "locked" END, 
			locked_datetime = CASE WHEN login_try_col >= 4 THEN locked_datetime_col ELSE locked_datetime END
		WHERE 
			email = _email;
		
		INSERT INTO log_user_login (email, ip, login_datetime, login_success )
		VALUES (_email, _login_ip, now()::timestamp, false);
		
	END IF;
END IF;

IF ( success = false) THEN
	last_login_ip_col := NULL;
	last_login_datetime_col := NULL;
	user_id_col := NULL;
END IF;
return_data := (select row_to_json(t)
from (
	select success as success,
			message as message,
			is_locked_col as "locked",
			is_locked_now as lockednow,
			login_try_col as logintry,
			user_id_col as userid,
			last_login_ip_col as lastloginip,
			last_login_datetime_col as lastlogindatetime
) t);

RETURN return_data;
END

$$;


CREATE FUNCTION create_form(_template_id integer, _form_data json, _user_id integer, _is_complete boolean) RETURNS TABLE(form_id integer)
    LANGUAGE plpgsql
    AS $$

DECLARE _form_data_id integer;
BEGIN

INSERT INTO form_data(form_template_id, "data", created_user_id, is_complete, last_updated_user_id, last_updated_datetime)
values ( _template_id, _form_data, _user_id, _is_complete, _user_id, CURRENT_TIMESTAMP at time zone 'utc') RETURNING ID into _form_data_id;

INSERT INTO user_form_relation (user_id, form_data_id, is_read_only)
values(_user_id, _form_data_id, false);

RETURN QUERY SELECT _form_data_id;

END

$$;


CREATE FUNCTION search_organization(search_criteria organization_search_criteria) RETURNS TABLE(tenant_id uuid, settings json)
    LANGUAGE plpgsql
    AS $$

BEGIN 
	RETURN QUERY SELECT o.tenant_id,o.settings FROM organization o 
	WHERE (search_criteria.tenant_id IS NULL OR o.tenant_id = search_criteria.tenant_id)
	AND o.domain_name = search_criteria.domain_name ;	
END;

$$;