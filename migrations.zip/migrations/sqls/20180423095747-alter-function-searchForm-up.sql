/* Replace with your SQL commands */
DROP FUNCTION public.search_form(form_search_criteria);

CREATE FUNCTION search_form(search_criteria form_search_criteria) 
RETURNS TABLE(form_id integer,owner_user_id integer, form_data json, form_template_id integer, form_template text, summary_fields json, form_title character varying, is_complete boolean, form_last_updated timestamp without time zone)
    LANGUAGE plpgsql
    AS $$

Begin
	
	
	RETURN QUERY Select FD.id,FD.created_user_id,FD."data", FD.form_template_id, FT.data, FT.summary_fields, F.title, FD.is_complete, FD.last_updated_datetime   
	FROM form_data FD 
	INNER JOIN form_template FT ON FT.id = FD.form_template_id
	INNER JOIN form F ON F.id = FT.form_id
	INNER JOIN category CAT ON CAT.id = F.category_id
	INNER JOIN section SEC on SEC.id = CAT.section_id
	WHERE (search_criteria.form_id IS NULL OR FD.id = search_criteria.form_id)
	AND (search_criteria.owner_id IS NULL OR FD.created_user_id = search_criteria.owner_id)
	AND (search_criteria.template_id IS NULL OR FT.id = search_criteria.template_id)
	AND (search_criteria.section_id IS NULL OR SEC.id = search_criteria.section_id)
	AND (search_criteria.last_update_start_date IS NULL OR FD.last_updated_datetime >= search_criteria.last_update_start_date :: date)
	AND (search_criteria.last_update_end_date IS NULL OR FD.last_updated_datetime < (search_criteria.last_update_end_date :: date + '1 day'::interval))
	AND (FD.is_complete = true OR (search_criteria.include_saved IS NOT NULL AND FD.is_complete = NOT search_criteria.include_saved))
	ORDER BY FD.last_updated_datetime desc;
	
	
End

$$;
