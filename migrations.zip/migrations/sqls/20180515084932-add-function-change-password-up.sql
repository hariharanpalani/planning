CREATE OR REPLACE FUNCTION public.change_password(
	_email character varying,
	password_old character varying,
	password_new character varying,
	_tenant_id uuid)
    RETURNS json
    LANGUAGE 'plpgsql'

    COST 100
    VOLATILE SECURITY DEFINER 
AS $BODY$

DECLARE salt_new UUID;
DECLARE salt_old UUID;
DECLARE password_hash_new CHARACTER VARYING(1000);
DECLARE password_hash_old CHARACTER VARYING(1000); 
DECLARE password_hash CHARACTER VARYING(1000); 
DECLARE user_id INTEGER = 0;
DECLARE success BOOLEAN;
DECLARE message CHARACTER VARYING(500);  
DECLARE return_data JSON;

BEGIN

	success := false;
	message := 'Unable to change password';
	
	SELECT u.password_hash, u.salt, u.User_Id
		INTO password_hash_old,salt_old,user_id
		FROM public.user u WHERE u.email = _email AND u.tenant_id = _tenant_id;
		
	IF (COALESCE(user_id,0) = 0) THEN
		message := 'User does not exist';
	ELSE	
		password_hash := crypt(password_old, salt_old::character varying(20));
		IF(password_hash = password_hash_old)
			THEN	
				salt_new := gen_random_uuid();
				password_hash_new := crypt(password_new, salt_new::character varying(20));	
				UPDATE public.user 
					SET salt = salt_new,
						password_hash = password_hash_new,
						login_try= 0,
						locked = false,
						locked_datetime = NULL
					WHERE email = _email AND tenant_id = _tenant_id;
  				success := true;
				message := 'Password changed successfully';
			ELSE
				message := 'Old password does not match';
		END IF;
	END IF;
	
	return_data := (select row_to_json(t)
	from (
		select success as success,
			   message as message
	) t);

	RETURN return_data;

END

$BODY$;