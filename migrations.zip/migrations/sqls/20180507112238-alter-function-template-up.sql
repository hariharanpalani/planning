DROP FUNCTION public.get_form_template(integer);

CREATE OR REPLACE FUNCTION public.get_form_template(
	_form_id integer)
    RETURNS TABLE(template_id integer, section_id integer, form_id integer, form_name character varying, tenant_id uuid, title character varying, description character varying, form_type character varying, fields text)
    LANGUAGE 'sql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

select FT.id, cat.section_id,F.id, F.name,cat.tenant_id, F.title,F.description, F.form_type, FT.data as fields 
from form F 
join form_template FT on F.id = FT.form_id AND FT.is_default = true
join category cat on (cat.id = f.category_id)
where F.id = _form_id and F.is_active = true

$function$;


CREATE OR REPLACE FUNCTION get_section_detail(_section_id integer) RETURNS TABLE(id integer, title character varying, tenant_id uuid, logo_path character varying, form_items json, res_items json)
    LANGUAGE plpgsql
    AS $$

DECLARE form_items json;
DECLARE res_items json;
DECLARE categories json;
BEGIN
	
	--form items
	select json_agg(fi.items) into form_items from 
	(select  json_build_object('name', cat.title, 'items', 
			json_agg(
			json_build_object(
								'id', frm.id, 
								'name', frm.name, 
								'title', frm.title,
								'description', frm.description, 
								'type', frm.form_type
			) order by tmpl.sort_order_id
			)
			) as items 
	from section s
	inner join category cat on cat.section_id = s.id and cat.is_active = true
	left outer join form frm on frm.category_id = cat.id and  frm.is_active = true
	left outer join form_template tmpl on tmpl.form_id = frm.id and tmpl.is_default = true
	where s.id = _section_id and s.is_active = true and cat.name = 'forms'
	group by cat.title) fi;

	select json_agg(r.items) into res_items from 
	(select json_build_object('name', cat.title, 'items', 
			json_agg(
			json_build_object(
								'id', res.id, 
								'name', res.name, 
								'title', res.title,
								'description', res.description,
								'type', res.resource_type,
								'property', res.property
			) order by res.sort_order_id
			)
			) as items
	from category cat
	left outer join resource res on  res.category_id = cat.id and res.is_active = true	
	inner join section s on s.id = cat.section_id and s.is_active = true
	where s.id = _section_id and cat.is_active = true and cat.name != 'forms'	
	group by cat.title, cat.sort_order_id Order by cat.sort_order_id) r;

		
	RETURN QUERY select s.id , s.title,s.tenant_id, s.logo_path, form_items , res_items from "section" s where s.id = _section_id;
END 

$$;


CREATE OR REPLACE FUNCTION public.update_form_template(
	_form_id integer,
	_template_fields text,
	_user_id integer)
    RETURNS TABLE(form_template_id integer)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

DECLARE _form_template_id integer = 0;
DECLARE _new_form_template_id integer;
BEGIN
    
SELECT "id" into _form_template_id FROM form_template WHERE form_id = _form_id AND is_default = true;
    
IF NOT FOUND THEN 
	RETURN QUERY SELECT 0;
ELSE
	UPDATE form_template SET is_default = false WHERE "id" = _form_template_id;

    INSERT INTO form_template (form_id, "data", version_id, is_default, created_datetime, created_user_id, summary_fields)
    SELECT form_id, _template_fields, (version_id + 1), true,  CURRENT_TIMESTAMP at time zone 'utc', _user_id, summary_fields 
    FROM form_template WHERE "id" = _form_template_id  RETURNING ID into _new_form_template_id;   

    RETURN QUERY SELECT _new_form_template_id;
END IF;

END

$function$;