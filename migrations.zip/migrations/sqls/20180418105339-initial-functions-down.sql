DROP FUNCTION public.search_organization(organization_search_criteria);

DROP FUNCTION public.create_form(integer, json, integer, boolean);

DROP FUNCTION public.validate_user_login(character varying, character varying, character varying);

DROP FUNCTION public.update_form(integer, json, boolean, integer, timestamp without time zone);

DROP FUNCTION public.search_user(user_search_criteria);

DROP FUNCTION public.search_form(form_search_criteria);

DROP FUNCTION public.get_user_sections(integer);

DROP FUNCTION public.get_user_info(integer);

DROP FUNCTION public.get_submitted_count(integer, integer);

DROP FUNCTION public.get_section_detail(integer);

DROP FUNCTION public.get_saved_count(integer, integer);

DROP FUNCTION public.get_form_users(integer);

DROP FUNCTION public.get_form_template(integer);

DROP FUNCTION public.get_form_data(integer);

DROP FUNCTION public.create_user_login(character varying, character varying, uuid, boolean, character varying);

DROP FUNCTION public.add_remove_form_users(integer, integer[]);


DROP TYPE public.user_search_criteria;

DROP TYPE public.organization_search_criteria;

DROP TYPE public.form_search_criteria;

DROP EXTENSION pgcrypto;