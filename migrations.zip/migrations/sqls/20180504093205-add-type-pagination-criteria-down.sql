/* Replace with your SQL commands */

DROP TYPE public.pagination_criteria;