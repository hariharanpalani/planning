update form_template set summary_fields = '[{"field":"positiontitle","title":"Position"}]' where form_id = 1;
update form_template set summary_fields = '[{"field":"name","title":"Candidate"}]' where form_id = 2;
update form_template set summary_fields = '[{"field":"candidatename","title":"Candidate"}]' where form_id = 3;
update form_template set summary_fields = '[{"field":"name","title":"Name"}]' where form_id = 6;
